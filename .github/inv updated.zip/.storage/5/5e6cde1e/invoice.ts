export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  
  // Business info
  businessName: string;
  businessAddress: string;
  businessEmail: string;
  businessPhone: string;
  
  // Client info
  clientName: string;
  clientAddress: string;
  clientEmail: string;
  
  // Invoice items
  items: InvoiceItem[];
  
  // Totals
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  
  // Additional
  notes: string;
  paymentTerms: string;
  
  createdAt: string;
}

export const createEmptyInvoice = (): Partial<Invoice> => ({
  invoiceNumber: `INV-${Date.now()}`,
  date: new Date().toISOString().split('T')[0],
  dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  items: [],
  subtotal: 0,
  taxRate: 0,
  taxAmount: 0,
  total: 0,
  notes: '',
  paymentTerms: 'Net 30',
});

export const calculateInvoiceTotals = (items: InvoiceItem[], taxRate: number) => {
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const taxAmount = (subtotal * taxRate) / 100;
  const total = subtotal + taxAmount;
  
  return { subtotal, taxAmount, total };
};

export const saveInvoice = (invoice: Invoice) => {
  const invoices = getInvoices();
  const existingIndex = invoices.findIndex(inv => inv.id === invoice.id);
  
  if (existingIndex >= 0) {
    invoices[existingIndex] = invoice;
  } else {
    invoices.push(invoice);
  }
  
  localStorage.setItem('invoices', JSON.stringify(invoices));
};

export const getInvoices = (): Invoice[] => {
  const stored = localStorage.getItem('invoices');
  return stored ? JSON.parse(stored) : [];
};

export const deleteInvoice = (id: string) => {
  const invoices = getInvoices().filter(inv => inv.id !== id);
  localStorage.setItem('invoices', JSON.stringify(invoices));
};