export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
  image?: string; // Added image field for item pictures
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  
  // Language and Currency
  language: string;
  currency: string;
  
  // Business info
  businessName: string;
  businessAddress: string;
  businessEmail: string;
  businessPhone: string;
  businessLogo?: string; // Added logo field
  
  // Client info
  clientName: string;
  clientAddress: string;
  clientEmail: string;
  
  // Invoice items
  items: InvoiceItem[];
  
  // Totals
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  
  // Additional
  notes: string;
  paymentTerms: string;
  
  createdAt: string;
}

export const SUPPORTED_LANGUAGES = {
  'en': 'English',
  'es': 'Español',
  'fr': 'Français',
  'de': 'Deutsch',
  'it': 'Italiano',
  'pt': 'Português',
  'zh': '中文',
  'ja': '日本語',
  'ko': '한국어',
  'ar': 'العربية'
};

export const SUPPORTED_CURRENCIES = {
  'USD': { symbol: '$', name: 'US Dollar' },
  'EUR': { symbol: '€', name: 'Euro' },
  'GBP': { symbol: '£', name: 'British Pound' },
  'JPY': { symbol: '¥', name: 'Japanese Yen' },
  'CAD': { symbol: 'C$', name: 'Canadian Dollar' },
  'AUD': { symbol: 'A$', name: 'Australian Dollar' },
  'CHF': { symbol: 'CHF', name: 'Swiss Franc' },
  'CNY': { symbol: '¥', name: 'Chinese Yuan' },
  'INR': { symbol: '₹', name: 'Indian Rupee' },
  'BRL': { symbol: 'R$', name: 'Brazilian Real' },
  'MXN': { symbol: '$', name: 'Mexican Peso' },
  'KRW': { symbol: '₩', name: 'South Korean Won' },
  'SAR': { symbol: 'ر.س', name: 'Saudi Riyal' },
  'AED': { symbol: 'د.إ', name: 'UAE Dirham' }
};

export const TRANSLATIONS = {
  en: {
    invoice: 'INVOICE',
    from: 'From:',
    billTo: 'Bill To:',
    date: 'Date:',
    due: 'Due:',
    description: 'Description',
    quantity: 'Qty',
    rate: 'Rate',
    amount: 'Amount',
    subtotal: 'Subtotal:',
    tax: 'Tax',
    total: 'Total:',
    paymentTerms: 'Payment Terms:',
    notes: 'Notes:',
    thankYou: 'Thank you for your business!'
  },
  es: {
    invoice: 'FACTURA',
    from: 'De:',
    billTo: 'Facturar a:',
    date: 'Fecha:',
    due: 'Vencimiento:',
    description: 'Descripción',
    quantity: 'Cant.',
    rate: 'Precio',
    amount: 'Total',
    subtotal: 'Subtotal:',
    tax: 'Impuesto',
    total: 'Total:',
    paymentTerms: 'Términos de pago:',
    notes: 'Notas:',
    thankYou: '¡Gracias por su negocio!'
  },
  fr: {
    invoice: 'FACTURE',
    from: 'De:',
    billTo: 'Facturer à:',
    date: 'Date:',
    due: 'Échéance:',
    description: 'Description',
    quantity: 'Qté',
    rate: 'Prix',
    amount: 'Montant',
    subtotal: 'Sous-total:',
    tax: 'Taxe',
    total: 'Total:',
    paymentTerms: 'Conditions de paiement:',
    notes: 'Notes:',
    thankYou: 'Merci pour votre entreprise!'
  },
  de: {
    invoice: 'RECHNUNG',
    from: 'Von:',
    billTo: 'Rechnung an:',
    date: 'Datum:',
    due: 'Fällig:',
    description: 'Beschreibung',
    quantity: 'Anz.',
    rate: 'Preis',
    amount: 'Betrag',
    subtotal: 'Zwischensumme:',
    tax: 'Steuer',
    total: 'Gesamt:',
    paymentTerms: 'Zahlungsbedingungen:',
    notes: 'Notizen:',
    thankYou: 'Vielen Dank für Ihr Geschäft!'
  },
  it: {
    invoice: 'FATTURA',
    from: 'Da:',
    billTo: 'Fatturare a:',
    date: 'Data:',
    due: 'Scadenza:',
    description: 'Descrizione',
    quantity: 'Qtà',
    rate: 'Prezzo',
    amount: 'Importo',
    subtotal: 'Subtotale:',
    tax: 'Tassa',
    total: 'Totale:',
    paymentTerms: 'Termini di pagamento:',
    notes: 'Note:',
    thankYou: 'Grazie per il vostro business!'
  },
  pt: {
    invoice: 'FATURA',
    from: 'De:',
    billTo: 'Faturar para:',
    date: 'Data:',
    due: 'Vencimento:',
    description: 'Descrição',
    quantity: 'Qtd',
    rate: 'Preço',
    amount: 'Valor',
    subtotal: 'Subtotal:',
    tax: 'Imposto',
    total: 'Total:',
    paymentTerms: 'Termos de pagamento:',
    notes: 'Notas:',
    thankYou: 'Obrigado pelo seu negócio!'
  },
  zh: {
    invoice: '发票',
    from: '发票方:',
    billTo: '收票方:',
    date: '日期:',
    due: '到期日:',
    description: '描述',
    quantity: '数量',
    rate: '单价',
    amount: '金额',
    subtotal: '小计:',
    tax: '税费',
    total: '总计:',
    paymentTerms: '付款条件:',
    notes: '备注:',
    thankYou: '感谢您的业务!'
  },
  ja: {
    invoice: '請求書',
    from: '差出人:',
    billTo: '宛先:',
    date: '日付:',
    due: '支払期限:',
    description: '項目',
    quantity: '数量',
    rate: '単価',
    amount: '金額',
    subtotal: '小計:',
    tax: '税金',
    total: '合計:',
    paymentTerms: '支払条件:',
    notes: '備考:',
    thankYou: 'ありがとうございました!'
  },
  ko: {
    invoice: '청구서',
    from: '발신자:',
    billTo: '수신자:',
    date: '날짜:',
    due: '만료일:',
    description: '설명',
    quantity: '수량',
    rate: '단가',
    amount: '금액',
    subtotal: '소계:',
    tax: '세금',
    total: '총액:',
    paymentTerms: '지불 조건:',
    notes: '메모:',
    thankYou: '감사합니다!'
  },
  ar: {
    invoice: 'فاتورة',
    from: 'من:',
    billTo: 'إلى:',
    date: 'التاريخ:',
    due: 'تاريخ الاستحقاق:',
    description: 'الوصف',
    quantity: 'الكمية',
    rate: 'السعر',
    amount: 'المبلغ',
    subtotal: 'المجموع الفرعي:',
    tax: 'الضريبة',
    total: 'المجموع:',
    paymentTerms: 'شروط الدفع:',
    notes: 'ملاحظات:',
    thankYou: 'شكرا لك على عملك!'
  }
};

export const createEmptyInvoice = (): Partial<Invoice> => ({
  invoiceNumber: `INV-${Date.now()}`,
  date: new Date().toISOString().split('T')[0],
  dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  language: 'en',
  currency: 'USD',
  items: [],
  subtotal: 0,
  taxRate: 0,
  taxAmount: 0,
  total: 0,
  notes: '',
  paymentTerms: 'Net 30',
});

export const calculateInvoiceTotals = (items: InvoiceItem[], taxRate: number) => {
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const taxAmount = (subtotal * taxRate) / 100;
  const total = subtotal + taxAmount;
  
  return { subtotal, taxAmount, total };
};

export const formatCurrency = (amount: number, currency: string) => {
  const currencyInfo = SUPPORTED_CURRENCIES[currency as keyof typeof SUPPORTED_CURRENCIES];
  if (!currencyInfo) return `$${amount.toFixed(2)}`;
  
  // For currencies like JPY and KRW that don't use decimals
  const decimals = ['JPY', 'KRW'].includes(currency) ? 0 : 2;
  
  return `${currencyInfo.symbol}${amount.toFixed(decimals)}`;
};

export const saveInvoice = (invoice: Invoice) => {
  const invoices = getInvoices();
  const existingIndex = invoices.findIndex(inv => inv.id === invoice.id);
  
  if (existingIndex >= 0) {
    invoices[existingIndex] = invoice;
  } else {
    invoices.push(invoice);
  }
  
  localStorage.setItem('invoices', JSON.stringify(invoices));
};

export const getInvoices = (): Invoice[] => {
  const stored = localStorage.getItem('invoices');
  return stored ? JSON.parse(stored) : [];
};

export const deleteInvoice = (id: string) => {
  const invoices = getInvoices().filter(inv => inv.id !== id);
  localStorage.setItem('invoices', JSON.stringify(invoices));
};