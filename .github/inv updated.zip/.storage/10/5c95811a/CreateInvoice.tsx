import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Eye, Save, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import InvoiceForm from '@/components/InvoiceForm';
import { Invoice, createEmptyInvoice, saveInvoice } from '@/lib/invoice';

export default function CreateInvoice() {
  const [invoice, setInvoice] = useState<Partial<Invoice>>(createEmptyInvoice);
  const navigate = useNavigate();

  const handleSave = () => {
    if (!invoice.businessName || !invoice.clientName || (invoice.items || []).length === 0) {
      alert('Please fill in business name, client name, and add at least one item.');
      return;
    }

    const savedInvoice: Invoice = {
      ...invoice,
      id: invoice.id || Date.now().toString(),
      createdAt: new Date().toISOString(),
    } as Invoice;

    saveInvoice(savedInvoice);
    navigate(`/preview/${savedInvoice.id}`);
  };

  const handlePreview = () => {
    const tempInvoice: Invoice = {
      ...invoice,
      id: 'preview',
      createdAt: new Date().toISOString(),
    } as Invoice;

    // Store temporary invoice for preview
    sessionStorage.setItem('previewInvoice', JSON.stringify(tempInvoice));
    navigate('/preview/preview');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Create New Invoice</h1>
          <p className="text-gray-600">Fill in the details below to create your professional invoice</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <InvoiceForm invoice={invoice} onChange={setInvoice} />
          </div>
          
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="text-lg font-semibold mb-4">Actions</h3>
                <div className="space-y-3">
                  <Button 
                    onClick={handlePreview} 
                    variant="outline" 
                    className="w-full flex items-center space-x-2"
                  >
                    <Eye className="h-4 w-4" />
                    <span>Preview Invoice</span>
                  </Button>
                  
                  <Button 
                    onClick={handleSave} 
                    className="w-full flex items-center space-x-2"
                  >
                    <Save className="h-4 w-4" />
                    <span>Save & Preview</span>
                  </Button>
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-blue-900 mb-2">💡 Pro Tips</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Fill in your business details first</li>
                  <li>• Add detailed item descriptions</li>
                  <li>• Set clear payment terms</li>
                  <li>• Preview before saving</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}