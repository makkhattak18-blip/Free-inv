import * as XLSX from 'xlsx';
import { Invoice, formatCurrency } from './invoice';

export const generateInvoiceSummaryExcel = (invoices: Invoice[]): void => {
  // Prepare data for Excel
  const summaryData = invoices.map(invoice => ({
    'Invoice Number': invoice.invoiceNumber || '',
    'Client Name': invoice.clientName || '',
    'Date': invoice.date || '',
    'Due Date': invoice.dueDate || '',
    'Currency': invoice.currency || 'USD',
    'Subtotal': invoice.subtotal || 0,
    'Tax Rate (%)': invoice.taxRate || 0,
    'Tax Amount': invoice.taxAmount || 0,
    'Total Amount': invoice.total || 0,
    'Payment Terms': invoice.paymentTerms || '',
    'Status': 'Generated', // You can enhance this with actual status tracking
    'Created At': invoice.createdAt || new Date().toISOString()
  }));

  // Create workbook
  const wb = XLSX.utils.book_new();
  
  // Summary sheet
  const summaryWs = XLSX.utils.json_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, summaryWs, 'Invoice Summary');
  
  // Statistics sheet
  const totalAmount = invoices.reduce((sum, inv) => sum + (inv.total || 0), 0);
  const avgAmount = invoices.length > 0 ? totalAmount / invoices.length : 0;
  const currencyBreakdown = invoices.reduce((acc, inv) => {
    const currency = inv.currency || 'USD';
    acc[currency] = (acc[currency] || 0) + (inv.total || 0);
    return acc;
  }, {} as Record<string, number>);
  
  const statsData = [
    { Metric: 'Total Invoices', Value: invoices.length },
    { Metric: 'Total Amount (All Currencies)', Value: totalAmount.toFixed(2) },
    { Metric: 'Average Invoice Amount', Value: avgAmount.toFixed(2) },
    { Metric: 'Report Generated', Value: new Date().toLocaleString() },
    ...Object.entries(currencyBreakdown).map(([currency, amount]) => ({
      Metric: `Total in ${currency}`,
      Value: amount.toFixed(2)
    }))
  ];
  
  const statsWs = XLSX.utils.json_to_sheet(statsData);
  XLSX.utils.book_append_sheet(wb, statsWs, 'Statistics');
  
  // Client breakdown sheet
  const clientBreakdown = invoices.reduce((acc, inv) => {
    const client = inv.clientName || 'Unknown Client';
    if (!acc[client]) {
      acc[client] = { count: 0, total: 0 };
    }
    acc[client].count += 1;
    acc[client].total += inv.total || 0;
    return acc;
  }, {} as Record<string, { count: number; total: number }>);
  
  const clientData = Object.entries(clientBreakdown).map(([client, data]) => ({
    'Client Name': client,
    'Number of Invoices': data.count,
    'Total Amount': data.total.toFixed(2),
    'Average Invoice': (data.total / data.count).toFixed(2)
  }));
  
  const clientWs = XLSX.utils.json_to_sheet(clientData);
  XLSX.utils.book_append_sheet(wb, clientWs, 'Client Breakdown');
  
  // Save file
  XLSX.writeFile(wb, `invoice-summary-${new Date().toISOString().split('T')[0]}.xlsx`);
};

export const generateDetailedInvoiceExcel = (invoices: Invoice[]): void => {
  const wb = XLSX.utils.book_new();
  
  // Detailed items sheet
  const itemsData: any[] = [];
  
  invoices.forEach(invoice => {
    (invoice.items || []).forEach(item => {
      itemsData.push({
        'Invoice Number': invoice.invoiceNumber || '',
        'Client Name': invoice.clientName || '',
        'Invoice Date': invoice.date || '',
        'Item Description': item.description || '',
        'Quantity': item.quantity || 0,
        'Rate': item.rate || 0,
        'Amount': item.amount || 0,
        'Currency': invoice.currency || 'USD'
      });
    });
  });
  
  const itemsWs = XLSX.utils.json_to_sheet(itemsData);
  XLSX.utils.book_append_sheet(wb, itemsWs, 'Invoice Items');
  
  // Monthly summary
  const monthlyData = invoices.reduce((acc, inv) => {
    if (inv.date) {
      const month = inv.date.substring(0, 7); // YYYY-MM format
      if (!acc[month]) {
        acc[month] = { count: 0, total: 0 };
      }
      acc[month].count += 1;
      acc[month].total += inv.total || 0;
    }
    return acc;
  }, {} as Record<string, { count: number; total: number }>);
  
  const monthlyDataArray = Object.entries(monthlyData)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, data]) => ({
      'Month': month,
      'Number of Invoices': data.count,
      'Total Amount': data.total.toFixed(2),
      'Average Invoice': (data.total / data.count).toFixed(2)
    }));
  
  const monthlyWs = XLSX.utils.json_to_sheet(monthlyDataArray);
  XLSX.utils.book_append_sheet(wb, monthlyWs, 'Monthly Summary');
  
  XLSX.writeFile(wb, `detailed-invoice-report-${new Date().toISOString().split('T')[0]}.xlsx`);
};