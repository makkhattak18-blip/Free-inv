import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Invoice, getLabels, formatCurrency } from './invoice';

export const generateInvoicePDF = async (invoice: Partial<Invoice>): Promise<void> => {
  const labels = getLabels(invoice);
  const currency = invoice.currency || 'USD';
  
  // Create new PDF document
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Set up fonts and colors
  pdf.setFont('helvetica');
  
  // Header
  pdf.setFontSize(24);
  pdf.setTextColor(51, 51, 51);
  pdf.text(labels.invoice, 20, 30);
  
  // Invoice number
  pdf.setFontSize(12);
  pdf.setTextColor(102, 102, 102);
  pdf.text(`#${invoice.invoiceNumber || ''}`, 20, 40);
  
  // Date information
  pdf.text(`${labels.date} ${invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}`, pageWidth - 60, 30);
  pdf.text(`${labels.due} ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}`, pageWidth - 60, 40);
  
  // Business information
  let yPos = 60;
  pdf.setFontSize(14);
  pdf.setTextColor(51, 51, 51);
  pdf.text(labels.from, 20, yPos);
  
  yPos += 10;
  pdf.setFontSize(12);
  if (invoice.businessName) {
    pdf.text(invoice.businessName, 20, yPos);
    yPos += 6;
  }
  if (invoice.businessAddress) {
    const addressLines = invoice.businessAddress.split('\n');
    addressLines.forEach(line => {
      pdf.text(line, 20, yPos);
      yPos += 6;
    });
  }
  if (invoice.businessEmail) {
    pdf.text(invoice.businessEmail, 20, yPos);
    yPos += 6;
  }
  if (invoice.businessPhone) {
    pdf.text(invoice.businessPhone, 20, yPos);
    yPos += 6;
  }
  
  // Client information
  let clientYPos = 60;
  pdf.setFontSize(14);
  pdf.setTextColor(51, 51, 51);
  pdf.text(labels.billTo, pageWidth - 80, clientYPos);
  
  clientYPos += 10;
  pdf.setFontSize(12);
  if (invoice.clientName) {
    pdf.text(invoice.clientName, pageWidth - 80, clientYPos);
    clientYPos += 6;
  }
  if (invoice.clientAddress) {
    const addressLines = invoice.clientAddress.split('\n');
    addressLines.forEach(line => {
      pdf.text(line, pageWidth - 80, clientYPos);
      clientYPos += 6;
    });
  }
  if (invoice.clientEmail) {
    pdf.text(invoice.clientEmail, pageWidth - 80, clientYPos);
    clientYPos += 6;
  }
  
  // Items table
  yPos = Math.max(yPos, clientYPos) + 20;
  
  // Table headers
  pdf.setFontSize(12);
  pdf.setTextColor(51, 51, 51);
  pdf.setFillColor(245, 245, 245);
  pdf.rect(20, yPos - 5, pageWidth - 40, 10, 'F');
  
  pdf.text(labels.description, 25, yPos);
  pdf.text(labels.quantity, pageWidth - 120, yPos);
  pdf.text(labels.rate, pageWidth - 80, yPos);
  pdf.text(labels.amount, pageWidth - 40, yPos);
  
  yPos += 15;
  
  // Items
  (invoice.items || []).forEach(item => {
    if (yPos > pageHeight - 50) {
      pdf.addPage();
      yPos = 30;
    }
    
    // Description (with word wrap)
    const descriptionLines = pdf.splitTextToSize(item.description, 100);
    pdf.text(descriptionLines, 25, yPos);
    
    pdf.text(item.quantity.toString(), pageWidth - 120, yPos);
    pdf.text(formatCurrency(item.rate, currency), pageWidth - 80, yPos);
    pdf.text(formatCurrency(item.amount, currency), pageWidth - 40, yPos);
    
    yPos += Math.max(descriptionLines.length * 6, 10);
  });
  
  // Totals
  yPos += 10;
  const totalsX = pageWidth - 80;
  
  pdf.text(`${labels.subtotal} ${formatCurrency(invoice.subtotal || 0, currency)}`, totalsX, yPos);
  yPos += 8;
  
  if ((invoice.taxRate || 0) > 0) {
    pdf.text(`${labels.tax} (${invoice.taxRate}%): ${formatCurrency(invoice.taxAmount || 0, currency)}`, totalsX, yPos);
    yPos += 8;
  }
  
  // Total line
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text(`${labels.total} ${formatCurrency(invoice.total || 0, currency)}`, totalsX, yPos);
  
  // Payment terms and notes
  yPos += 20;
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  
  if (invoice.paymentTerms) {
    pdf.text(`${labels.paymentTerms} ${invoice.paymentTerms}`, 20, yPos);
    yPos += 10;
  }
  
  if (invoice.notes) {
    pdf.text(labels.notes, 20, yPos);
    yPos += 8;
    const notesLines = pdf.splitTextToSize(invoice.notes, pageWidth - 40);
    pdf.text(notesLines, 20, yPos);
    yPos += notesLines.length * 6;
  }
  
  // Thank you message
  yPos += 10;
  pdf.setTextColor(102, 102, 102);
  pdf.text(labels.thankYou, 20, yPos);
  
  // Save the PDF
  const fileName = `invoice-${invoice.invoiceNumber || Date.now()}.pdf`;
  pdf.save(fileName);
};

export const generateInvoiceSummaryPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  // Title
  pdf.setFontSize(20);
  pdf.setTextColor(51, 51, 51);
  pdf.text('Invoice Summary Report', 20, 30);
  
  // Date range
  pdf.setFontSize(12);
  pdf.setTextColor(102, 102, 102);
  pdf.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 40);
  pdf.text(`Total Invoices: ${invoices.length}`, 20, 50);
  
  // Calculate totals
  const totalAmount = invoices.reduce((sum, inv) => sum + (inv.total || 0), 0);
  pdf.text(`Total Amount: $${totalAmount.toFixed(2)}`, 20, 60);
  
  // Table headers
  let yPos = 80;
  pdf.setFillColor(245, 245, 245);
  pdf.rect(20, yPos - 5, pageWidth - 40, 10, 'F');
  
  pdf.setTextColor(51, 51, 51);
  pdf.text('Invoice #', 25, yPos);
  pdf.text('Client', 70, yPos);
  pdf.text('Date', 120, yPos);
  pdf.text('Amount', pageWidth - 40, yPos);
  
  yPos += 15;
  
  // Invoice list
  invoices.forEach(invoice => {
    if (yPos > 270) {
      pdf.addPage();
      yPos = 30;
    }
    
    pdf.setFontSize(10);
    pdf.text(invoice.invoiceNumber || '', 25, yPos);
    pdf.text(invoice.clientName || '', 70, yPos);
    pdf.text(invoice.date ? new Date(invoice.date).toLocaleDateString() : '', 120, yPos);
    pdf.text(`$${(invoice.total || 0).toFixed(2)}`, pageWidth - 40, yPos);
    
    yPos += 8;
  });
  
  pdf.save('invoice-summary.pdf');
};

export const generateAllInvoicesPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  for (let i = 0; i < invoices.length; i++) {
    if (i > 0) {
      pdf.addPage();
    }
    
    const invoice = invoices[i];
    const labels = getLabels(invoice);
    const currency = invoice.currency || 'USD';
    const pageWidth = pdf.internal.pageSize.getWidth();
    
    // Header
    pdf.setFontSize(24);
    pdf.setTextColor(51, 51, 51);
    pdf.text(labels.invoice, 20, 30);
    
    // Invoice number
    pdf.setFontSize(12);
    pdf.setTextColor(102, 102, 102);
    pdf.text(`#${invoice.invoiceNumber || ''}`, 20, 40);
    
    // Date information
    pdf.text(`${labels.date} ${invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}`, pageWidth - 60, 30);
    pdf.text(`${labels.due} ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}`, pageWidth - 60, 40);
    
    // Business and client info (simplified for bulk export)
    let yPos = 60;
    pdf.setFontSize(12);
    pdf.text(`${labels.from} ${invoice.businessName || ''}`, 20, yPos);
    pdf.text(`${labels.billTo} ${invoice.clientName || ''}`, 20, yPos + 10);
    
    yPos += 30;
    
    // Items summary
    pdf.text('Items:', 20, yPos);
    yPos += 10;
    
    (invoice.items || []).forEach(item => {
      pdf.setFontSize(10);
      pdf.text(`${item.description} - ${item.quantity} x ${formatCurrency(item.rate, currency)} = ${formatCurrency(item.amount, currency)}`, 25, yPos);
      yPos += 6;
    });
    
    // Total
    yPos += 10;
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`${labels.total} ${formatCurrency(invoice.total || 0, currency)}`, 20, yPos);
    pdf.setFont('helvetica', 'normal');
  }
  
  pdf.save('all-invoices.pdf');
};