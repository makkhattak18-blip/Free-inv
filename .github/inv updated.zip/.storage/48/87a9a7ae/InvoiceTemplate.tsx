import { Invoice, getLabels, formatCurrency } from '@/lib/invoice';

interface InvoiceTemplateProps {
  invoice: Partial<Invoice>;
}

export default function InvoiceTemplate({ invoice }: InvoiceTemplateProps) {
  const labels = getLabels(invoice);
  const currency = invoice.currency || 'USD';
  const language = invoice.language || 'en';
  const isRTL = language === 'ar' || language === 'ur';

  return (
    <div 
      className={`bg-white p-8 shadow-lg rounded-lg max-w-4xl mx-auto ${isRTL ? 'rtl' : 'ltr'}`}
      data-invoice-preview
      style={{ direction: isRTL ? 'rtl' : 'ltr' }}
    >
      {/* Business Logo */}
      {invoice.businessLogo && (
        <div className="text-center mb-8">
          <img 
            src={invoice.businessLogo} 
            alt="Business Logo" 
            className="max-w-48 max-h-24 mx-auto object-contain"
          />
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            {labels.invoice}
          </h1>
          <p className="text-lg text-gray-600">
            #{invoice.invoiceNumber}
          </p>
        </div>
        <div className={`text-${isRTL ? 'left' : 'right'}`}>
          <p className="text-sm text-gray-600 mb-1">
            <span className="font-semibold">{labels.date}:</span> {invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-semibold">{labels.due}:</span> {invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}
          </p>
        </div>
      </div>

      {/* Business and Client Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-3">{labels.from}</h3>
          <div className="text-gray-700">
            {invoice.businessName && <p className="font-semibold">{invoice.businessName}</p>}
            {invoice.businessAddress && (
              <p className="whitespace-pre-line">{invoice.businessAddress}</p>
            )}
            {invoice.businessEmail && <p>{invoice.businessEmail}</p>}
            {invoice.businessPhone && <p>{invoice.businessPhone}</p>}
          </div>
        </div>
        
        <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
          <h3 className="text-lg font-semibold text-gray-900 mb-3">{labels.billTo}</h3>
          <div className="text-gray-700">
            {invoice.clientName && <p className="font-semibold">{invoice.clientName}</p>}
            {invoice.clientAddress && (
              <p className="whitespace-pre-line">{invoice.clientAddress}</p>
            )}
            {invoice.clientEmail && <p>{invoice.clientEmail}</p>}
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-8">
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-50">
              <th className="border border-gray-300 px-4 py-3 text-left font-semibold text-gray-900">
                {labels.description}
              </th>
              <th className="border border-gray-300 px-4 py-3 text-center font-semibold text-gray-900">
                {labels.quantity}
              </th>
              <th className="border border-gray-300 px-4 py-3 text-right font-semibold text-gray-900">
                {labels.rate}
              </th>
              <th className="border border-gray-300 px-4 py-3 text-right font-semibold text-gray-900">
                {labels.amount}
              </th>
            </tr>
          </thead>
          <tbody>
            {(invoice.items || []).map((item, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="border border-gray-300 px-4 py-3">
                  <div>
                    {item.description}
                    {item.image && (
                      <div className="mt-2">
                        <img 
                          src={item.image} 
                          alt="Item" 
                          className="max-w-16 max-h-16 object-cover rounded"
                        />
                      </div>
                    )}
                  </div>
                </td>
                <td className="border border-gray-300 px-4 py-3 text-center">
                  {item.quantity}
                </td>
                <td className="border border-gray-300 px-4 py-3 text-right">
                  {formatCurrency(item.rate, currency)}
                </td>
                <td className="border border-gray-300 px-4 py-3 text-right font-semibold">
                  {formatCurrency(item.amount, currency)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className={`flex justify-end mb-8`}>
        <div className="w-64">
          <div className="flex justify-between py-2">
            <span className="font-semibold">{labels.subtotal}:</span>
            <span>{formatCurrency(invoice.subtotal || 0, currency)}</span>
          </div>
          
          {(invoice.taxRate || 0) > 0 && (
            <div className="flex justify-between py-2">
              <span className="font-semibold">{labels.tax} ({invoice.taxRate}%):</span>
              <span>{formatCurrency(invoice.taxAmount || 0, currency)}</span>
            </div>
          )}
          
          <div className="border-t border-gray-300 pt-2 mt-2">
            <div className="flex justify-between py-2">
              <span className="text-xl font-bold">{labels.total}:</span>
              <span className="text-xl font-bold text-green-600">
                {formatCurrency(invoice.total || 0, currency)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Terms */}
      {invoice.paymentTerms && (
        <div className="mb-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-2">{labels.paymentTerms}</h4>
          <p className="text-gray-700">{invoice.paymentTerms}</p>
        </div>
      )}

      {/* Notes */}
      {invoice.notes && (
        <div className="mb-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-2">{labels.notes}</h4>
          <p className="text-gray-700 whitespace-pre-line">{invoice.notes}</p>
        </div>
      )}

      {/* Thank You */}
      <div className="text-center mt-8 pt-6 border-t border-gray-200">
        <p className="text-lg text-gray-600">{labels.thankYou}</p>
      </div>
    </div>
  );
}