export const WEBSITE_LANGUAGES = {
  en: 'English',
  ar: 'العربية',
  zh: '中文'
};

export const WEBSITE_TRANSLATIONS = {
  en: {
    // Navigation
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    welcome: 'Welcome',
    
    // Home Page
    heroTitle: 'Professional Invoice Creator',
    heroSubtitle: 'Create beautiful, multilingual invoices with custom branding, multiple currencies, and professional templates',
    createInvoiceNow: 'Create Invoice Now',
    viewHistory: 'View History & Reports',
    
    // Features
    featuresTitle: 'Features',
    languages: 'Languages',
    languagesDesc: 'Support for multiple languages with complete translations and RTL support for Arabic and Urdu.',
    currencies: 'Currencies',
    currenciesDesc: 'Support for major world currencies with proper formatting and symbols.',
    customLabels: 'Custom Labels',
    customLabelsDesc: 'Fully customizable headers and labels. Create invoices, quotes, estimates, or receipts.',
    exportReports: 'Export & Reports',
    exportReportsDesc: 'Download individual PDFs, bulk exports, and comprehensive Excel reports with analytics.',
    
    // Quick Start
    quickStartTitle: 'Quick Start',
    quickStartDesc: 'Choose your preferred language and currency to get started with a pre-configured invoice',
    allLanguagesTitle: 'All Supported Languages',
    allLanguagesDesc: 'Click any language above to start creating an invoice in that language',
    createCustomInvoice: 'Create Custom Invoice',
    
    // Footer
    footerText: 'Professional invoice creator supporting 12 languages and 16 currencies',
    footerSubtext: 'Perfect for international businesses and freelancers',
    
    // Auth Modal
    authModalTitle: 'Welcome to Invoice Creator',
    email: 'Email',
    password: 'Password',
    fullName: 'Full Name',
    confirmPassword: 'Confirm Password',
    signingIn: 'Signing In...',
    creatingAccount: 'Creating Account...',
    enterEmail: 'Enter your email',
    enterPassword: 'Enter your password',
    enterFullName: 'Enter your full name',
    enterPasswordMin: 'Enter your password (min 6 characters)',
    confirmPasswordText: 'Confirm your password',
    createAccount: 'Create Account',
    dataPrivacy: 'Your invoices will be saved locally and only visible to you.',
    
    // Invoice Creation
    createInvoice: 'Create Invoice',
    preview: 'Preview',
    backToHome: 'Back to Home',
    downloadPDF: 'Download PDF',
    
    // Invoice History
    invoiceHistory: 'Invoice History & Reports',
    createNewInvoice: 'Create New Invoice'
  },
  
  ar: {
    // Navigation
    signIn: 'تسجيل الدخول',
    signUp: 'إنشاء حساب',
    signOut: 'تسجيل الخروج',
    welcome: 'مرحباً',
    
    // Home Page
    heroTitle: 'منشئ الفواتير المحترف',
    heroSubtitle: 'إنشاء فواتير جميلة ومتعددة اللغات مع العلامة التجارية المخصصة والعملات المتعددة والقوالب المهنية',
    createInvoiceNow: 'إنشاء فاتورة الآن',
    viewHistory: 'عرض التاريخ والتقارير',
    
    // Features
    featuresTitle: 'الميزات',
    languages: 'اللغات',
    languagesDesc: 'دعم للغات متعددة مع ترجمات كاملة ودعم RTL للعربية والأردية.',
    currencies: 'العملات',
    currenciesDesc: 'دعم للعملات العالمية الرئيسية مع التنسيق والرموز المناسبة.',
    customLabels: 'التسميات المخصصة',
    customLabelsDesc: 'رؤوس وتسميات قابلة للتخصيص بالكامل. إنشاء فواتير أو عروض أسعار أو تقديرات أو إيصالات.',
    exportReports: 'التصدير والتقارير',
    exportReportsDesc: 'تنزيل ملفات PDF فردية وتصدير مجمع وتقارير Excel شاملة مع التحليلات.',
    
    // Quick Start
    quickStartTitle: 'البداية السريعة',
    quickStartDesc: 'اختر لغتك وعملتك المفضلة للبدء بفاتورة معدة مسبقاً',
    allLanguagesTitle: 'جميع اللغات المدعومة',
    allLanguagesDesc: 'انقر على أي لغة أعلاه لبدء إنشاء فاتورة بتلك اللغة',
    createCustomInvoice: 'إنشاء فاتورة مخصصة',
    
    // Footer
    footerText: 'منشئ فواتير محترف يدعم 12 لغة و 16 عملة',
    footerSubtext: 'مثالي للشركات الدولية والمستقلين',
    
    // Auth Modal
    authModalTitle: 'مرحباً بك في منشئ الفواتير',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    fullName: 'الاسم الكامل',
    confirmPassword: 'تأكيد كلمة المرور',
    signingIn: 'جاري تسجيل الدخول...',
    creatingAccount: 'جاري إنشاء الحساب...',
    enterEmail: 'أدخل بريدك الإلكتروني',
    enterPassword: 'أدخل كلمة المرور',
    enterFullName: 'أدخل اسمك الكامل',
    enterPasswordMin: 'أدخل كلمة المرور (6 أحرف على الأقل)',
    confirmPasswordText: 'تأكيد كلمة المرور',
    createAccount: 'إنشاء حساب',
    dataPrivacy: 'ستُحفظ فواتيرك محلياً وستكون مرئية لك فقط.',
    
    // Invoice Creation
    createInvoice: 'إنشاء فاتورة',
    preview: 'معاينة',
    backToHome: 'العودة للرئيسية',
    downloadPDF: 'تنزيل PDF',
    
    // Invoice History
    invoiceHistory: 'تاريخ الفواتير والتقارير',
    createNewInvoice: 'إنشاء فاتورة جديدة'
  },
  
  zh: {
    // Navigation
    signIn: '登录',
    signUp: '注册',
    signOut: '退出',
    welcome: '欢迎',
    
    // Home Page
    heroTitle: '专业发票创建器',
    heroSubtitle: '创建美观的多语言发票，支持自定义品牌、多种货币和专业模板',
    createInvoiceNow: '立即创建发票',
    viewHistory: '查看历史记录和报告',
    
    // Features
    featuresTitle: '功能特色',
    languages: '多语言',
    languagesDesc: '支持多种语言，提供完整翻译和阿拉伯语、乌尔都语的RTL支持。',
    currencies: '多货币',
    currenciesDesc: '支持主要世界货币，具有适当的格式和符号。',
    customLabels: '自定义标签',
    customLabelsDesc: '完全可定制的标题和标签。创建发票、报价单、估价单或收据。',
    exportReports: '导出和报告',
    exportReportsDesc: '下载单个PDF、批量导出和包含分析的综合Excel报告。',
    
    // Quick Start
    quickStartTitle: '快速开始',
    quickStartDesc: '选择您偏好的语言和货币，开始使用预配置的发票',
    allLanguagesTitle: '所有支持的语言',
    allLanguagesDesc: '点击上面任何语言开始创建该语言的发票',
    createCustomInvoice: '创建自定义发票',
    
    // Footer
    footerText: '支持12种语言和16种货币的专业发票创建器',
    footerSubtext: '适合国际企业和自由职业者',
    
    // Auth Modal
    authModalTitle: '欢迎使用发票创建器',
    email: '电子邮箱',
    password: '密码',
    fullName: '全名',
    confirmPassword: '确认密码',
    signingIn: '正在登录...',
    creatingAccount: '正在创建账户...',
    enterEmail: '输入您的电子邮箱',
    enterPassword: '输入您的密码',
    enterFullName: '输入您的全名',
    enterPasswordMin: '输入您的密码（至少6个字符）',
    confirmPasswordText: '确认您的密码',
    createAccount: '创建账户',
    dataPrivacy: '您的发票将保存在本地，仅对您可见。',
    
    // Invoice Creation
    createInvoice: '创建发票',
    preview: '预览',
    backToHome: '返回首页',
    downloadPDF: '下载PDF',
    
    // Invoice History
    invoiceHistory: '发票历史记录和报告',
    createNewInvoice: '创建新发票'
  }
};

export const getWebsiteTranslation = (language: string) => {
  return WEBSITE_TRANSLATIONS[language as keyof typeof WEBSITE_TRANSLATIONS] || WEBSITE_TRANSLATIONS.en;
};