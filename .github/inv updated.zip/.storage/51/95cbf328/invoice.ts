import { getCurrentUser } from './auth';

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
  image?: string;
}

export interface Invoice {
  id: string;
  userId: string; // Add user ID for filtering
  invoiceNumber: string;
  date: string;
  dueDate: string;
  businessName: string;
  businessAddress: string;
  businessEmail: string;
  businessPhone: string;
  businessLogo?: string;
  clientName: string;
  clientAddress: string;
  clientEmail: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  currency: string;
  language: string;
  paymentTerms?: string;
  notes?: string;
  customLabels?: {
    invoice?: string;
    from?: string;
    billTo?: string;
    date?: string;
    due?: string;
    description?: string;
    quantity?: string;
    rate?: string;
    amount?: string;
    subtotal?: string;
    tax?: string;
    total?: string;
    paymentTerms?: string;
    notes?: string;
    thankYou?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export const SUPPORTED_LANGUAGES = {
  en: 'English',
  es: 'Español',
  fr: 'Français',
  de: 'Deutsch',
  it: 'Italiano',
  pt: 'Português',
  zh: '中文',
  ja: '日本語',
  ko: '한국어',
  ar: 'العربية',
  ur: 'اردو',
  bn: 'বাংলা'
};

export const SUPPORTED_CURRENCIES = {
  USD: 'US Dollar',
  EUR: 'Euro',
  GBP: 'British Pound',
  JPY: 'Japanese Yen',
  CAD: 'Canadian Dollar',
  AUD: 'Australian Dollar',
  CHF: 'Swiss Franc',
  CNY: 'Chinese Yuan',
  INR: 'Indian Rupee',
  BRL: 'Brazilian Real',
  MXN: 'Mexican Peso',
  KRW: 'South Korean Won',
  SAR: 'Saudi Riyal',
  AED: 'UAE Dirham',
  PKR: 'Pakistani Rupee',
  BDT: 'Bangladeshi Taka'
};

const TRANSLATIONS = {
  en: {
    invoice: 'Invoice',
    from: 'From',
    billTo: 'Bill To',
    date: 'Date',
    due: 'Due Date',
    description: 'Description',
    quantity: 'Qty',
    rate: 'Rate',
    amount: 'Amount',
    subtotal: 'Subtotal',
    tax: 'Tax',
    total: 'Total',
    paymentTerms: 'Payment Terms',
    notes: 'Notes',
    thankYou: 'Thank you for your business!'
  },
  es: {
    invoice: 'Factura',
    from: 'De',
    billTo: 'Facturar A',
    date: 'Fecha',
    due: 'Vencimiento',
    description: 'Descripción',
    quantity: 'Cant.',
    rate: 'Precio',
    amount: 'Importe',
    subtotal: 'Subtotal',
    tax: 'Impuesto',
    total: 'Total',
    paymentTerms: 'Términos de Pago',
    notes: 'Notas',
    thankYou: '¡Gracias por su negocio!'
  },
  fr: {
    invoice: 'Facture',
    from: 'De',
    billTo: 'Facturer À',
    date: 'Date',
    due: 'Échéance',
    description: 'Description',
    quantity: 'Qté',
    rate: 'Prix',
    amount: 'Montant',
    subtotal: 'Sous-total',
    tax: 'Taxe',
    total: 'Total',
    paymentTerms: 'Conditions de Paiement',
    notes: 'Notes',
    thankYou: 'Merci pour votre entreprise!'
  },
  de: {
    invoice: 'Rechnung',
    from: 'Von',
    billTo: 'Rechnung An',
    date: 'Datum',
    due: 'Fällig',
    description: 'Beschreibung',
    quantity: 'Menge',
    rate: 'Preis',
    amount: 'Betrag',
    subtotal: 'Zwischensumme',
    tax: 'Steuer',
    total: 'Gesamt',
    paymentTerms: 'Zahlungsbedingungen',
    notes: 'Notizen',
    thankYou: 'Vielen Dank für Ihr Geschäft!'
  },
  it: {
    invoice: 'Fattura',
    from: 'Da',
    billTo: 'Fattura A',
    date: 'Data',
    due: 'Scadenza',
    description: 'Descrizione',
    quantity: 'Qtà',
    rate: 'Prezzo',
    amount: 'Importo',
    subtotal: 'Subtotale',
    tax: 'Tassa',
    total: 'Totale',
    paymentTerms: 'Termini di Pagamento',
    notes: 'Note',
    thankYou: 'Grazie per il vostro business!'
  },
  pt: {
    invoice: 'Fatura',
    from: 'De',
    billTo: 'Faturar Para',
    date: 'Data',
    due: 'Vencimento',
    description: 'Descrição',
    quantity: 'Qtd',
    rate: 'Preço',
    amount: 'Valor',
    subtotal: 'Subtotal',
    tax: 'Imposto',
    total: 'Total',
    paymentTerms: 'Termos de Pagamento',
    notes: 'Notas',
    thankYou: 'Obrigado pelo seu negócio!'
  },
  zh: {
    invoice: '发票',
    from: '发件人',
    billTo: '收件人',
    date: '日期',
    due: '到期日',
    description: '描述',
    quantity: '数量',
    rate: '单价',
    amount: '金额',
    subtotal: '小计',
    tax: '税费',
    total: '总计',
    paymentTerms: '付款条件',
    notes: '备注',
    thankYou: '感谢您的业务！'
  },
  ja: {
    invoice: '請求書',
    from: '差出人',
    billTo: '宛先',
    date: '日付',
    due: '支払期限',
    description: '説明',
    quantity: '数量',
    rate: '単価',
    amount: '金額',
    subtotal: '小計',
    tax: '税金',
    total: '合計',
    paymentTerms: '支払条件',
    notes: '備考',
    thankYou: 'ご利用ありがとうございます！'
  },
  ko: {
    invoice: '청구서',
    from: '발신자',
    billTo: '수신자',
    date: '날짜',
    due: '만료일',
    description: '설명',
    quantity: '수량',
    rate: '단가',
    amount: '금액',
    subtotal: '소계',
    tax: '세금',
    total: '총계',
    paymentTerms: '결제 조건',
    notes: '메모',
    thankYou: '비즈니스에 감사드립니다!'
  },
  ar: {
    invoice: 'فاتورة',
    from: 'من',
    billTo: 'إلى',
    date: 'التاريخ',
    due: 'تاريخ الاستحقاق',
    description: 'الوصف',
    quantity: 'الكمية',
    rate: 'السعر',
    amount: 'المبلغ',
    subtotal: 'المجموع الفرعي',
    tax: 'الضريبة',
    total: 'الإجمالي',
    paymentTerms: 'شروط الدفع',
    notes: 'ملاحظات',
    thankYou: 'شكراً لك على عملك!'
  },
  ur: {
    invoice: 'بل',
    from: 'سے',
    billTo: 'کو',
    date: 'تاریخ',
    due: 'آخری تاریخ',
    description: 'تفصیل',
    quantity: 'مقدار',
    rate: 'قیمت',
    amount: 'رقم',
    subtotal: 'ذیلی کل',
    tax: 'ٹیکس',
    total: 'کل',
    paymentTerms: 'ادائیگی کی شرائط',
    notes: 'نوٹس',
    thankYou: 'آپ کے کاروبار کے لیے شکریہ!'
  },
  bn: {
    invoice: 'চালান',
    from: 'থেকে',
    billTo: 'প্রাপক',
    date: 'তারিখ',
    due: 'শেষ তারিখ',
    description: 'বিবরণ',
    quantity: 'পরিমাণ',
    rate: 'হার',
    amount: 'পরিমাণ',
    subtotal: 'উপমোট',
    tax: 'কর',
    total: 'মোট',
    paymentTerms: 'পেমেন্ট শর্তাবলী',
    notes: 'নোট',
    thankYou: 'আপনার ব্যবসার জন্য ধন্যবাদ!'
  }
};

export const getLabels = (invoice?: Partial<Invoice>) => {
  const language = invoice?.language || 'en';
  const customLabels = invoice?.customLabels || {};
  const defaultLabels = TRANSLATIONS[language as keyof typeof TRANSLATIONS] || TRANSLATIONS.en;
  
  return {
    ...defaultLabels,
    ...customLabels
  };
};

export const formatCurrency = (amount: number, currency: string): string => {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
  } catch (error) {
    return `${currency} ${amount.toFixed(2)}`;
  }
};

export const createEmptyInvoice = (): Partial<Invoice> => {
  const user = getCurrentUser();
  return {
    id: Date.now().toString(),
    userId: user?.id || '',
    invoiceNumber: `INV-${Date.now()}`,
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    businessName: '',
    businessAddress: '',
    businessEmail: '',
    businessPhone: '',
    clientName: '',
    clientAddress: '',
    clientEmail: '',
    items: [],
    subtotal: 0,
    taxRate: 0,
    taxAmount: 0,
    total: 0,
    currency: 'USD',
    language: 'en',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
};

export const calculateInvoiceTotals = (invoice: Partial<Invoice>): Partial<Invoice> => {
  const items = invoice.items || [];
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const taxRate = invoice.taxRate || 0;
  const taxAmount = (subtotal * taxRate) / 100;
  const total = subtotal + taxAmount;

  return {
    ...invoice,
    subtotal,
    taxAmount,
    total,
    updatedAt: new Date().toISOString()
  };
};

const getStorageKey = (userId: string) => `invoices_${userId}`;

export const saveInvoice = (invoice: Partial<Invoice>): void => {
  const user = getCurrentUser();
  if (!user) return;

  const storageKey = getStorageKey(user.id);
  const invoices = getInvoices();
  
  const invoiceWithUser = {
    ...invoice,
    userId: user.id,
    updatedAt: new Date().toISOString()
  };

  const existingIndex = invoices.findIndex(inv => inv.id === invoice.id);
  
  if (existingIndex >= 0) {
    invoices[existingIndex] = invoiceWithUser as Invoice;
  } else {
    invoices.push(invoiceWithUser as Invoice);
  }

  localStorage.setItem(storageKey, JSON.stringify(invoices));
};

export const getInvoices = (): Invoice[] => {
  const user = getCurrentUser();
  if (!user) return [];

  const storageKey = getStorageKey(user.id);
  
  try {
    const stored = localStorage.getItem(storageKey);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading invoices:', error);
    return [];
  }
};

export const deleteInvoice = (id: string): void => {
  const user = getCurrentUser();
  if (!user) return;

  const storageKey = getStorageKey(user.id);
  const invoices = getInvoices();
  const filtered = invoices.filter(inv => inv.id !== id);
  localStorage.setItem(storageKey, JSON.stringify(filtered));
};

export const getInvoiceById = (id: string): Invoice | null => {
  const invoices = getInvoices();
  return invoices.find(inv => inv.id === id) || null;
};