import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, Upload, X, Globe, DollarSign, Edit3 } from 'lucide-react';
import { Invoice, InvoiceItem, calculateInvoiceTotals, SUPPORTED_LANGUAGES, SUPPORTED_CURRENCIES, formatCurrency, getLabels, saveInvoice } from '@/lib/invoice';

interface InvoiceFormProps {
  invoice: Partial<Invoice>;
  onChange: (invoice: Partial<Invoice>) => void;
}

export default function InvoiceForm({ invoice, onChange }: InvoiceFormProps) {
  const [showCustomLabels, setShowCustomLabels] = useState(false);
  const labels = getLabels(invoice);

  useEffect(() => {
    // Auto-save invoice when it changes
    if (invoice.id && invoice.businessName) {
      saveInvoice(invoice);
    }
  }, [invoice]);

  const updateInvoice = (updates: Partial<Invoice>) => {
    const updatedInvoice = calculateInvoiceTotals({ ...invoice, ...updates });
    onChange(updatedInvoice);
  };

  const addItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      description: '',
      quantity: 1,
      rate: 0,
      amount: 0
    };
    updateInvoice({
      items: [...(invoice.items || []), newItem]
    });
  };

  const updateItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    const items = [...(invoice.items || [])];
    items[index] = { ...items[index], [field]: value };
    
    if (field === 'quantity' || field === 'rate') {
      items[index].amount = items[index].quantity * items[index].rate;
    }
    
    updateInvoice({ items });
  };

  const removeItem = (index: number) => {
    const items = [...(invoice.items || [])];
    items.splice(index, 1);
    updateInvoice({ items });
  };

  const handleFileUpload = (file: File, type: 'logo' | 'item', itemIndex?: number) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (type === 'logo') {
        updateInvoice({ businessLogo: result });
      } else if (type === 'item' && itemIndex !== undefined) {
        updateItem(itemIndex, 'image', result);
      }
    };
    reader.readAsDataURL(file);
  };

  const updateCustomLabel = (key: string, value: string) => {
    const customLabels = { ...invoice.customLabels, [key]: value };
    updateInvoice({ customLabels });
  };

  return (
    <div className="space-y-6">
      {/* Language and Currency Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-5 w-5" />
            <span>Language & Currency</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="language">Language</Label>
            <Select value={invoice.language} onValueChange={(value) => updateInvoice({ language: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(SUPPORTED_LANGUAGES).map(([code, name]) => (
                  <SelectItem key={code} value={code}>{name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="currency">Currency</Label>
            <Select value={invoice.currency} onValueChange={(value) => updateInvoice({ currency: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(SUPPORTED_CURRENCIES).map(([code, name]) => (
                  <SelectItem key={code} value={code}>{code} - {name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Custom Labels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Edit3 className="h-5 w-5" />
              <span>Custom Labels</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowCustomLabels(!showCustomLabels)}
            >
              {showCustomLabels ? 'Hide' : 'Customize'}
            </Button>
          </CardTitle>
        </CardHeader>
        {showCustomLabels && (
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Invoice Title</Label>
              <Input
                value={invoice.customLabels?.invoice || ''}
                onChange={(e) => updateCustomLabel('invoice', e.target.value)}
                placeholder={labels.invoice}
              />
            </div>
            <div>
              <Label>From Label</Label>
              <Input
                value={invoice.customLabels?.from || ''}
                onChange={(e) => updateCustomLabel('from', e.target.value)}
                placeholder={labels.from}
              />
            </div>
            <div>
              <Label>Bill To Label</Label>
              <Input
                value={invoice.customLabels?.billTo || ''}
                onChange={(e) => updateCustomLabel('billTo', e.target.value)}
                placeholder={labels.billTo}
              />
            </div>
            <div>
              <Label>Date Label</Label>
              <Input
                value={invoice.customLabels?.date || ''}
                onChange={(e) => updateCustomLabel('date', e.target.value)}
                placeholder={labels.date}
              />
            </div>
            <div>
              <Label>Due Date Label</Label>
              <Input
                value={invoice.customLabels?.due || ''}
                onChange={(e) => updateCustomLabel('due', e.target.value)}
                placeholder={labels.due}
              />
            </div>
            <div>
              <Label>Description Label</Label>
              <Input
                value={invoice.customLabels?.description || ''}
                onChange={(e) => updateCustomLabel('description', e.target.value)}
                placeholder={labels.description}
              />
            </div>
            <div>
              <Label>Quantity Label</Label>
              <Input
                value={invoice.customLabels?.quantity || ''}
                onChange={(e) => updateCustomLabel('quantity', e.target.value)}
                placeholder={labels.quantity}
              />
            </div>
            <div>
              <Label>Rate Label</Label>
              <Input
                value={invoice.customLabels?.rate || ''}
                onChange={(e) => updateCustomLabel('rate', e.target.value)}
                placeholder={labels.rate}
              />
            </div>
            <div>
              <Label>Amount Label</Label>
              <Input
                value={invoice.customLabels?.amount || ''}
                onChange={(e) => updateCustomLabel('amount', e.target.value)}
                placeholder={labels.amount}
              />
            </div>
            <div>
              <Label>Subtotal Label</Label>
              <Input
                value={invoice.customLabels?.subtotal || ''}
                onChange={(e) => updateCustomLabel('subtotal', e.target.value)}
                placeholder={labels.subtotal}
              />
            </div>
            <div>
              <Label>Tax Label</Label>
              <Input
                value={invoice.customLabels?.tax || ''}
                onChange={(e) => updateCustomLabel('tax', e.target.value)}
                placeholder={labels.tax}
              />
            </div>
            <div>
              <Label>Total Label</Label>
              <Input
                value={invoice.customLabels?.total || ''}
                onChange={(e) => updateCustomLabel('total', e.target.value)}
                placeholder={labels.total}
              />
            </div>
            <div>
              <Label>Payment Terms Label</Label>
              <Input
                value={invoice.customLabels?.paymentTerms || ''}
                onChange={(e) => updateCustomLabel('paymentTerms', e.target.value)}
                placeholder={labels.paymentTerms}
              />
            </div>
            <div>
              <Label>Notes Label</Label>
              <Input
                value={invoice.customLabels?.notes || ''}
                onChange={(e) => updateCustomLabel('notes', e.target.value)}
                placeholder={labels.notes}
              />
            </div>
            <div className="md:col-span-2">
              <Label>Thank You Message</Label>
              <Input
                value={invoice.customLabels?.thankYou || ''}
                onChange={(e) => updateCustomLabel('thankYou', e.target.value)}
                placeholder={labels.thankYou}
              />
            </div>
          </CardContent>
        )}
      </Card>

      {/* Invoice Details */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice Details</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="invoiceNumber">Invoice Number</Label>
            <Input
              id="invoiceNumber"
              value={invoice.invoiceNumber}
              onChange={(e) => updateInvoice({ invoiceNumber: e.target.value })}
              placeholder="INV-001"
            />
          </div>

          <div>
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              value={invoice.date}
              onChange={(e) => updateInvoice({ date: e.target.value })}
            />
          </div>

          <div className="md:col-span-2">
            <Label htmlFor="dueDate">Due Date</Label>
            <Input
              id="dueDate"
              type="date"
              value={invoice.dueDate}
              onChange={(e) => updateInvoice({ dueDate: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Business Information */}
      <Card>
        <CardHeader>
          <CardTitle>{labels.from}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="businessLogo">Business Logo</Label>
            <div className="flex items-center space-x-4">
              {invoice.businessLogo && (
                <div className="relative">
                  <img 
                    src={invoice.businessLogo} 
                    alt="Business Logo" 
                    className="w-20 h-20 object-contain border rounded"
                  />
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute -top-2 -right-2 h-6 w-6 p-0"
                    onClick={() => updateInvoice({ businessLogo: undefined })}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              )}
              <Button
                variant="outline"
                onClick={() => document.getElementById('logoUpload')?.click()}
                className="flex items-center space-x-2"
              >
                <Upload className="h-4 w-4" />
                <span>Upload Logo</span>
              </Button>
              <input
                id="logoUpload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileUpload(file, 'logo');
                }}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="businessName">Business Name</Label>
            <Input
              id="businessName"
              value={invoice.businessName}
              onChange={(e) => updateInvoice({ businessName: e.target.value })}
              placeholder="Your Business Name"
            />
          </div>

          <div>
            <Label htmlFor="businessAddress">Business Address</Label>
            <Textarea
              id="businessAddress"
              value={invoice.businessAddress}
              onChange={(e) => updateInvoice({ businessAddress: e.target.value })}
              placeholder="123 Business St&#10;City, State 12345&#10;Country"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="businessEmail">Business Email</Label>
              <Input
                id="businessEmail"
                type="email"
                value={invoice.businessEmail}
                onChange={(e) => updateInvoice({ businessEmail: e.target.value })}
                placeholder="business@example.com"
              />
            </div>

            <div>
              <Label htmlFor="businessPhone">Business Phone</Label>
              <Input
                id="businessPhone"
                value={invoice.businessPhone}
                onChange={(e) => updateInvoice({ businessPhone: e.target.value })}
                placeholder="+1 (555) 123-4567"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Client Information */}
      <Card>
        <CardHeader>
          <CardTitle>{labels.billTo}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="clientName">Client Name</Label>
            <Input
              id="clientName"
              value={invoice.clientName}
              onChange={(e) => updateInvoice({ clientName: e.target.value })}
              placeholder="Client Name"
            />
          </div>

          <div>
            <Label htmlFor="clientAddress">Client Address</Label>
            <Textarea
              id="clientAddress"
              value={invoice.clientAddress}
              onChange={(e) => updateInvoice({ clientAddress: e.target.value })}
              placeholder="123 Client St&#10;City, State 12345&#10;Country"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="clientEmail">Client Email</Label>
            <Input
              id="clientEmail"
              type="email"
              value={invoice.clientEmail}
              onChange={(e) => updateInvoice({ clientEmail: e.target.value })}
              placeholder="client@example.com"
            />
          </div>
        </CardContent>
      </Card>

      {/* Items */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Items</span>
            <Button onClick={addItem} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {(invoice.items || []).map((item, index) => (
            <div key={item.id} className="p-4 border rounded-lg space-y-4">
              <div className="flex justify-between items-start">
                <h4 className="font-semibold">Item {index + 1}</h4>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => removeItem(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor={`description-${index}`}>Description</Label>
                  <Textarea
                    id={`description-${index}`}
                    value={item.description}
                    onChange={(e) => updateItem(index, 'description', e.target.value)}
                    placeholder="Item description"
                    rows={2}
                  />
                </div>

                <div>
                  <Label>Item Image</Label>
                  <div className="flex items-center space-x-2">
                    {item.image && (
                      <div className="relative">
                        <img 
                          src={item.image} 
                          alt="Item" 
                          className="w-16 h-16 object-cover border rounded"
                        />
                        <Button
                          size="sm"
                          variant="destructive"
                          className="absolute -top-2 -right-2 h-6 w-6 p-0"
                          onClick={() => updateItem(index, 'image', '')}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => document.getElementById(`itemUpload-${index}`)?.click()}
                    >
                      <Upload className="h-4 w-4" />
                    </Button>
                    <input
                      id={`itemUpload-${index}`}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(file, 'item', index);
                      }}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor={`quantity-${index}`}>Quantity</Label>
                  <Input
                    id={`quantity-${index}`}
                    type="number"
                    min="0"
                    step="0.01"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, 'quantity', parseFloat(e.target.value) || 0)}
                  />
                </div>

                <div>
                  <Label htmlFor={`rate-${index}`}>Rate</Label>
                  <Input
                    id={`rate-${index}`}
                    type="number"
                    min="0"
                    step="0.01"
                    value={item.rate}
                    onChange={(e) => updateItem(index, 'rate', parseFloat(e.target.value) || 0)}
                  />
                </div>

                <div>
                  <Label>Amount</Label>
                  <div className="p-2 bg-gray-50 rounded border">
                    {formatCurrency(item.amount, invoice.currency || 'USD')}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {(!invoice.items || invoice.items.length === 0) && (
            <div className="text-center py-8 text-gray-500">
              <p>No items added yet. Click "Add Item" to get started.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tax and Totals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <DollarSign className="h-5 w-5" />
            <span>Tax & Totals</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="taxRate">Tax Rate (%)</Label>
            <Input
              id="taxRate"
              type="number"
              min="0"
              max="100"
              step="0.01"
              value={invoice.taxRate || 0}
              onChange={(e) => updateInvoice({ taxRate: parseFloat(e.target.value) || 0 })}
              placeholder="0.00"
            />
          </div>

          <Separator />

          <div className="space-y-2">
            <div className="flex justify-between">
              <span>{labels.subtotal}:</span>
              <span>{formatCurrency(invoice.subtotal || 0, invoice.currency || 'USD')}</span>
            </div>

            {(invoice.taxRate || 0) > 0 && (
              <div className="flex justify-between">
                <span>{labels.tax} ({invoice.taxRate}%):</span>
                <span>{formatCurrency(invoice.taxAmount || 0, invoice.currency || 'USD')}</span>
              </div>
            )}

            <Separator />

            <div className="flex justify-between text-lg font-bold">
              <span>{labels.total}:</span>
              <span className="text-green-600">
                {formatCurrency(invoice.total || 0, invoice.currency || 'USD')}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Additional Information */}
      <Card>
        <CardHeader>
          <CardTitle>Additional Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="paymentTerms">Payment Terms</Label>
            <Textarea
              id="paymentTerms"
              value={invoice.paymentTerms}
              onChange={(e) => updateInvoice({ paymentTerms: e.target.value })}
              placeholder="Net 30 days"
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={invoice.notes}
              onChange={(e) => updateInvoice({ notes: e.target.value })}
              placeholder="Additional notes or terms"
              rows={3}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}