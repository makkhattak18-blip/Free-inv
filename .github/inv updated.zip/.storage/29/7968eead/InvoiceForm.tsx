import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, Upload, X, Globe, DollarSign, Edit3 } from 'lucide-react';
import { Invoice, InvoiceItem, calculateInvoiceTotals, SUPPORTED_LANGUAGES, SUPPORTED_CURRENCIES, formatCurrency, getLabels, DEFAULT_TRANSLATIONS } from '@/lib/invoice';

interface InvoiceFormProps {
  invoice: Partial<Invoice>;
  onChange: (invoice: Partial<Invoice>) => void;
}

export default function InvoiceForm({ invoice, onChange }: InvoiceFormProps) {
  const labels = getLabels(invoice);

  const addItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      description: '',
      quantity: 1,
      rate: 0,
      amount: 0,
      image: ''
    };
    
    onChange({
      ...invoice,
      items: [...(invoice.items || []), newItem]
    });
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: string | number) => {
    const items = (invoice.items || []).map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        if (field === 'quantity' || field === 'rate') {
          updated.amount = updated.quantity * updated.rate;
        }
        return updated;
      }
      return item;
    });
    
    const totals = calculateInvoiceTotals(items, invoice.taxRate || 0);
    
    onChange({
      ...invoice,
      items,
      ...totals
    });
  };

  const removeItem = (id: string) => {
    const items = (invoice.items || []).filter(item => item.id !== id);
    const totals = calculateInvoiceTotals(items, invoice.taxRate || 0);
    
    onChange({
      ...invoice,
      items,
      ...totals
    });
  };

  const updateTaxRate = (taxRate: number) => {
    const totals = calculateInvoiceTotals(invoice.items || [], taxRate);
    
    onChange({
      ...invoice,
      taxRate,
      ...totals
    });
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        onChange({
          ...invoice,
          businessLogo: e.target?.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleItemImageUpload = (itemId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        updateItem(itemId, 'image', e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    onChange({
      ...invoice,
      businessLogo: ''
    });
  };

  const removeItemImage = (itemId: string) => {
    updateItem(itemId, 'image', '');
  };

  const updateCustomLabel = (key: keyof typeof labels, value: string) => {
    const currentLabels = invoice.customLabels || getLabels(invoice);
    onChange({
      ...invoice,
      customLabels: {
        ...currentLabels,
        [key]: value
      }
    });
  };

  const resetToDefaultLabels = () => {
    const language = invoice.language || 'en';
    const defaultLabels = DEFAULT_TRANSLATIONS[language as keyof typeof DEFAULT_TRANSLATIONS] || DEFAULT_TRANSLATIONS.en;
    onChange({
      ...invoice,
      customLabels: defaultLabels
    });
  };

  return (
    <div className="space-y-6">
      {/* Language and Currency Settings */}
      <Card className="border-blue-200 bg-blue-50/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-5 w-5 text-blue-600" />
            <span>Language & Currency Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="language">Invoice Language</Label>
              <Select
                value={invoice.language || 'en'}
                onValueChange={(value) => onChange({ ...invoice, language: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(SUPPORTED_LANGUAGES).map(([code, name]) => (
                    <SelectItem key={code} value={code}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={invoice.currency || 'USD'}
                onValueChange={(value) => onChange({ ...invoice, currency: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(SUPPORTED_CURRENCIES).map(([code, info]) => (
                    <SelectItem key={code} value={code}>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono">{info.symbol}</span>
                        <span>{code} - {info.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Custom Labels Editor */}
      <Card className="border-green-200 bg-green-50/50">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Edit3 className="h-5 w-5 text-green-600" />
              <span>Custom Invoice Labels</span>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={resetToDefaultLabels}
              className="text-xs"
            >
              Reset to Default
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="label-invoice">Invoice Title</Label>
              <Input
                id="label-invoice"
                value={labels.invoice}
                onChange={(e) => updateCustomLabel('invoice', e.target.value)}
                placeholder="INVOICE"
              />
            </div>
            
            <div>
              <Label htmlFor="label-from">From Label</Label>
              <Input
                id="label-from"
                value={labels.from}
                onChange={(e) => updateCustomLabel('from', e.target.value)}
                placeholder="From:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-billTo">Bill To Label</Label>
              <Input
                id="label-billTo"
                value={labels.billTo}
                onChange={(e) => updateCustomLabel('billTo', e.target.value)}
                placeholder="Bill To:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-date">Date Label</Label>
              <Input
                id="label-date"
                value={labels.date}
                onChange={(e) => updateCustomLabel('date', e.target.value)}
                placeholder="Date:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-due">Due Date Label</Label>
              <Input
                id="label-due"
                value={labels.due}
                onChange={(e) => updateCustomLabel('due', e.target.value)}
                placeholder="Due:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-description">Description Label</Label>
              <Input
                id="label-description"
                value={labels.description}
                onChange={(e) => updateCustomLabel('description', e.target.value)}
                placeholder="Description"
              />
            </div>
            
            <div>
              <Label htmlFor="label-quantity">Quantity Label</Label>
              <Input
                id="label-quantity"
                value={labels.quantity}
                onChange={(e) => updateCustomLabel('quantity', e.target.value)}
                placeholder="Qty"
              />
            </div>
            
            <div>
              <Label htmlFor="label-rate">Rate Label</Label>
              <Input
                id="label-rate"
                value={labels.rate}
                onChange={(e) => updateCustomLabel('rate', e.target.value)}
                placeholder="Rate"
              />
            </div>
            
            <div>
              <Label htmlFor="label-amount">Amount Label</Label>
              <Input
                id="label-amount"
                value={labels.amount}
                onChange={(e) => updateCustomLabel('amount', e.target.value)}
                placeholder="Amount"
              />
            </div>
            
            <div>
              <Label htmlFor="label-subtotal">Subtotal Label</Label>
              <Input
                id="label-subtotal"
                value={labels.subtotal}
                onChange={(e) => updateCustomLabel('subtotal', e.target.value)}
                placeholder="Subtotal:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-tax">Tax Label</Label>
              <Input
                id="label-tax"
                value={labels.tax}
                onChange={(e) => updateCustomLabel('tax', e.target.value)}
                placeholder="Tax"
              />
            </div>
            
            <div>
              <Label htmlFor="label-total">Total Label</Label>
              <Input
                id="label-total"
                value={labels.total}
                onChange={(e) => updateCustomLabel('total', e.target.value)}
                placeholder="Total:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-paymentTerms">Payment Terms Label</Label>
              <Input
                id="label-paymentTerms"
                value={labels.paymentTerms}
                onChange={(e) => updateCustomLabel('paymentTerms', e.target.value)}
                placeholder="Payment Terms:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-notes">Notes Label</Label>
              <Input
                id="label-notes"
                value={labels.notes}
                onChange={(e) => updateCustomLabel('notes', e.target.value)}
                placeholder="Notes:"
              />
            </div>
            
            <div>
              <Label htmlFor="label-thankYou">Thank You Message</Label>
              <Input
                id="label-thankYou"
                value={labels.thankYou}
                onChange={(e) => updateCustomLabel('thankYou', e.target.value)}
                placeholder="Thank you for your business!"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Details */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="invoiceNumber">Invoice Number</Label>
              <Input
                id="invoiceNumber"
                value={invoice.invoiceNumber || ''}
                onChange={(e) => onChange({ ...invoice, invoiceNumber: e.target.value })}
                placeholder="INV-001"
              />
            </div>
            <div>
              <Label htmlFor="date">Invoice Date</Label>
              <Input
                id="date"
                type="date"
                value={invoice.date || ''}
                onChange={(e) => onChange({ ...invoice, date: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={invoice.dueDate || ''}
                onChange={(e) => onChange({ ...invoice, dueDate: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Business Information */}
      <Card>
        <CardHeader>
          <CardTitle>Your Business Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Company Logo */}
          <div>
            <Label>Company Logo</Label>
            <div className="mt-2">
              {invoice.businessLogo ? (
                <div className="relative inline-block">
                  <img 
                    src={invoice.businessLogo} 
                    alt="Company Logo" 
                    className="h-20 w-auto object-contain border rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                    onClick={removeLogo}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                    id="logo-upload"
                  />
                  <Label 
                    htmlFor="logo-upload" 
                    className="cursor-pointer flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Upload Logo</span>
                  </Label>
                </div>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="businessName">Business Name</Label>
            <Input
              id="businessName"
              value={invoice.businessName || ''}
              onChange={(e) => onChange({ ...invoice, businessName: e.target.value })}
              placeholder="Your Business Name"
            />
          </div>
          <div>
            <Label htmlFor="businessAddress">Business Address</Label>
            <Textarea
              id="businessAddress"
              value={invoice.businessAddress || ''}
              onChange={(e) => onChange({ ...invoice, businessAddress: e.target.value })}
              placeholder="123 Business St, City, State, ZIP"
              rows={3}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="businessEmail">Email</Label>
              <Input
                id="businessEmail"
                type="email"
                value={invoice.businessEmail || ''}
                onChange={(e) => onChange({ ...invoice, businessEmail: e.target.value })}
                placeholder="business@example.com"
              />
            </div>
            <div>
              <Label htmlFor="businessPhone">Phone</Label>
              <Input
                id="businessPhone"
                value={invoice.businessPhone || ''}
                onChange={(e) => onChange({ ...invoice, businessPhone: e.target.value })}
                placeholder="(555) 123-4567"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Client Information */}
      <Card>
        <CardHeader>
          <CardTitle>Client Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="clientName">Client Name</Label>
            <Input
              id="clientName"
              value={invoice.clientName || ''}
              onChange={(e) => onChange({ ...invoice, clientName: e.target.value })}
              placeholder="Client Name or Company"
            />
          </div>
          <div>
            <Label htmlFor="clientAddress">Client Address</Label>
            <Textarea
              id="clientAddress"
              value={invoice.clientAddress || ''}
              onChange={(e) => onChange({ ...invoice, clientAddress: e.target.value })}
              placeholder="Client Address"
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="clientEmail">Client Email</Label>
            <Input
              id="clientEmail"
              type="email"
              value={invoice.clientEmail || ''}
              onChange={(e) => onChange({ ...invoice, clientEmail: e.target.value })}
              placeholder="client@example.com"
            />
          </div>
        </CardContent>
      </Card>

      {/* Invoice Items */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Invoice Items
            <Button onClick={addItem} size="sm" className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Add Item</span>
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {(invoice.items || []).length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>No items added yet. Click "Add Item" to get started.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {(invoice.items || []).map((item) => (
                <div key={item.id} className="p-4 border rounded-lg space-y-4">
                  {/* Item Image */}
                  <div>
                    <Label>Item Image (Optional)</Label>
                    <div className="mt-2">
                      {item.image ? (
                        <div className="relative inline-block">
                          <img 
                            src={item.image} 
                            alt="Item" 
                            className="h-16 w-16 object-cover border rounded-lg"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                            onClick={() => removeItemImage(item.id)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleItemImageUpload(item.id, e)}
                            className="hidden"
                            id={`item-image-${item.id}`}
                          />
                          <Label 
                            htmlFor={`item-image-${item.id}`} 
                            className="cursor-pointer flex items-center space-x-2 px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50"
                          >
                            <Upload className="h-3 w-3" />
                            <span>Add Image</span>
                          </Label>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Item Details */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                    <div className="md:col-span-5">
                      <Label>Description</Label>
                      <Textarea
                        value={item.description}
                        onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                        placeholder="Item description"
                        rows={2}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label>Quantity</Label>
                      <Input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateItem(item.id, 'quantity', Number(e.target.value))}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label>Rate ({SUPPORTED_CURRENCIES[invoice.currency as keyof typeof SUPPORTED_CURRENCIES]?.symbol || '$'})</Label>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={item.rate}
                        onChange={(e) => updateItem(item.id, 'rate', Number(e.target.value))}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label>Amount</Label>
                      <Input
                        value={formatCurrency(item.amount, invoice.currency || 'USD')}
                        disabled
                        className="bg-gray-50"
                      />
                    </div>
                    <div className="md:col-span-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => removeItem(item.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Totals */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice Totals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="taxRate">Tax Rate (%)</Label>
              <Input
                id="taxRate"
                type="number"
                min="0"
                max="100"
                step="0.1"
                value={invoice.taxRate || 0}
                onChange={(e) => updateTaxRate(Number(e.target.value))}
              />
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>{labels.subtotal}</span>
              <span>{formatCurrency(invoice.subtotal || 0, invoice.currency || 'USD')}</span>
            </div>
            <div className="flex justify-between">
              <span>{labels.tax} ({invoice.taxRate || 0}%):</span>
              <span>{formatCurrency(invoice.taxAmount || 0, invoice.currency || 'USD')}</span>
            </div>
            <Separator />
            <div className="flex justify-between text-lg font-semibold">
              <span>{labels.total}</span>
              <span>{formatCurrency(invoice.total || 0, invoice.currency || 'USD')}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Additional Information */}
      <Card>
        <CardHeader>
          <CardTitle>Additional Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="paymentTerms">Payment Terms</Label>
            <Input
              id="paymentTerms"
              value={invoice.paymentTerms || ''}
              onChange={(e) => onChange({ ...invoice, paymentTerms: e.target.value })}
              placeholder="Net 30"
            />
          </div>
          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={invoice.notes || ''}
              onChange={(e) => onChange({ ...invoice, notes: e.target.value })}
              placeholder="Additional notes or payment instructions"
              rows={4}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}