import jsPDF from 'jspdf';
import { Invoice, getLabels, formatCurrency } from './invoice';

// Simple text rendering function that handles Unicode better
const renderText = (pdf: jsPDF, text: string, x: number, y: number, options?: { align?: 'left' | 'right' | 'center', maxWidth?: number }) => {
  try {
    if (options?.maxWidth) {
      const lines = pdf.splitTextToSize(text, options.maxWidth);
      if (options.align === 'right') {
        lines.forEach((line: string, index: number) => {
          const lineWidth = pdf.getTextWidth(line);
          pdf.text(line, x - lineWidth, y + (index * 6));
        });
      } else {
        pdf.text(lines, x, y);
      }
      return lines.length * 6;
    } else {
      if (options?.align === 'right') {
        const textWidth = pdf.getTextWidth(text);
        pdf.text(text, x - textWidth, y);
      } else {
        pdf.text(text, x, y);
      }
      return 6;
    }
  } catch (error) {
    console.warn('Text rendering error, using fallback:', error);
    // Fallback: render as simple text
    pdf.text(text || '', x, y);
    return 6;
  }
};

export const generateInvoicePDF = async (invoice: Partial<Invoice>): Promise<void> => {
  const labels = getLabels(invoice);
  const currency = invoice.currency || 'USD';
  const language = invoice.language || 'en';
  
  // Create new PDF document
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Set font to helvetica which has better Unicode support
  pdf.setFont('helvetica', 'normal');
  
  // Determine if RTL language for layout adjustments
  const isRTL = language === 'ar' || language === 'ur';
  
  // Header section
  pdf.setFontSize(24);
  pdf.setTextColor(51, 51, 51);
  if (isRTL) {
    renderText(pdf, labels.invoice, pageWidth - 20, 30, { align: 'right' });
  } else {
    renderText(pdf, labels.invoice, 20, 30);
  }
  
  // Invoice number
  pdf.setFontSize(12);
  pdf.setTextColor(102, 102, 102);
  const invoiceNum = `#${invoice.invoiceNumber || ''}`;
  if (isRTL) {
    renderText(pdf, invoiceNum, pageWidth - 20, 40, { align: 'right' });
  } else {
    renderText(pdf, invoiceNum, 20, 40);
  }
  
  // Date information
  const dateText = `${labels.date}: ${invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}`;
  const dueText = `${labels.due}: ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}`;
  
  if (isRTL) {
    renderText(pdf, dateText, 20, 30);
    renderText(pdf, dueText, 20, 40);
  } else {
    renderText(pdf, dateText, pageWidth - 20, 30, { align: 'right' });
    renderText(pdf, dueText, pageWidth - 20, 40, { align: 'right' });
  }
  
  // Business information section
  let yPos = 60;
  pdf.setFontSize(14);
  pdf.setTextColor(51, 51, 51);
  
  const fromX = isRTL ? pageWidth - 20 : 20;
  const fromAlign = isRTL ? 'right' : 'left';
  
  renderText(pdf, labels.from, fromX, yPos, { align: fromAlign as 'left' | 'right' });
  
  yPos += 10;
  pdf.setFontSize(12);
  
  if (invoice.businessName) {
    renderText(pdf, invoice.businessName, fromX, yPos, { align: fromAlign as 'left' | 'right' });
    yPos += 6;
  }
  
  if (invoice.businessAddress) {
    const addressLines = invoice.businessAddress.split('\n');
    addressLines.forEach(line => {
      renderText(pdf, line, fromX, yPos, { align: fromAlign as 'left' | 'right' });
      yPos += 6;
    });
  }
  
  if (invoice.businessEmail) {
    renderText(pdf, invoice.businessEmail, fromX, yPos, { align: fromAlign as 'left' | 'right' });
    yPos += 6;
  }
  
  if (invoice.businessPhone) {
    renderText(pdf, invoice.businessPhone, fromX, yPos, { align: fromAlign as 'left' | 'right' });
    yPos += 6;
  }
  
  // Client information section
  let clientYPos = 60;
  pdf.setFontSize(14);
  pdf.setTextColor(51, 51, 51);
  
  const clientX = isRTL ? 20 : pageWidth - 20;
  const clientAlign = isRTL ? 'left' : 'right';
  
  renderText(pdf, labels.billTo, clientX, clientYPos, { align: clientAlign as 'left' | 'right' });
  
  clientYPos += 10;
  pdf.setFontSize(12);
  
  if (invoice.clientName) {
    renderText(pdf, invoice.clientName, clientX, clientYPos, { align: clientAlign as 'left' | 'right' });
    clientYPos += 6;
  }
  
  if (invoice.clientAddress) {
    const addressLines = invoice.clientAddress.split('\n');
    addressLines.forEach(line => {
      renderText(pdf, line, clientX, clientYPos, { align: clientAlign as 'left' | 'right' });
      clientYPos += 6;
    });
  }
  
  if (invoice.clientEmail) {
    renderText(pdf, invoice.clientEmail, clientX, clientYPos, { align: clientAlign as 'left' | 'right' });
    clientYPos += 6;
  }
  
  // Items table
  yPos = Math.max(yPos, clientYPos) + 20;
  
  // Table header background
  pdf.setFontSize(12);
  pdf.setTextColor(51, 51, 51);
  pdf.setFillColor(245, 245, 245);
  pdf.rect(20, yPos - 5, pageWidth - 40, 10, 'F');
  
  // Table headers with proper positioning
  if (isRTL) {
    renderText(pdf, labels.amount, pageWidth - 25, yPos, { align: 'right' });
    renderText(pdf, labels.rate, pageWidth - 70, yPos, { align: 'right' });
    renderText(pdf, labels.quantity, pageWidth - 110, yPos, { align: 'right' });
    renderText(pdf, labels.description, pageWidth - 150, yPos, { align: 'right' });
  } else {
    renderText(pdf, labels.description, 25, yPos);
    renderText(pdf, labels.quantity, pageWidth - 120, yPos);
    renderText(pdf, labels.rate, pageWidth - 80, yPos);
    renderText(pdf, labels.amount, pageWidth - 25, yPos, { align: 'right' });
  }
  
  yPos += 15;
  
  // Items rows
  (invoice.items || []).forEach(item => {
    if (yPos > pageHeight - 50) {
      pdf.addPage();
      pdf.setFont('helvetica', 'normal');
      yPos = 30;
    }
    
    if (isRTL) {
      renderText(pdf, formatCurrency(item.amount, currency), pageWidth - 25, yPos, { align: 'right' });
      renderText(pdf, formatCurrency(item.rate, currency), pageWidth - 70, yPos, { align: 'right' });
      renderText(pdf, item.quantity.toString(), pageWidth - 110, yPos, { align: 'right' });
      const descHeight = renderText(pdf, item.description, pageWidth - 150, yPos, { align: 'right', maxWidth: 100 });
      yPos += Math.max(descHeight, 10);
    } else {
      const descHeight = renderText(pdf, item.description, 25, yPos, { maxWidth: 100 });
      renderText(pdf, item.quantity.toString(), pageWidth - 120, yPos);
      renderText(pdf, formatCurrency(item.rate, currency), pageWidth - 80, yPos);
      renderText(pdf, formatCurrency(item.amount, currency), pageWidth - 25, yPos, { align: 'right' });
      yPos += Math.max(descHeight, 10);
    }
  });
  
  // Totals section
  yPos += 10;
  const totalsX = isRTL ? 20 : pageWidth - 20;
  const totalsAlign = isRTL ? 'left' : 'right';
  
  const subtotalText = `${labels.subtotal}: ${formatCurrency(invoice.subtotal || 0, currency)}`;
  renderText(pdf, subtotalText, totalsX, yPos, { align: totalsAlign as 'left' | 'right' });
  yPos += 8;
  
  if ((invoice.taxRate || 0) > 0) {
    const taxText = `${labels.tax} (${invoice.taxRate}%): ${formatCurrency(invoice.taxAmount || 0, currency)}`;
    renderText(pdf, taxText, totalsX, yPos, { align: totalsAlign as 'left' | 'right' });
    yPos += 8;
  }
  
  // Total line (bold)
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  const totalText = `${labels.total}: ${formatCurrency(invoice.total || 0, currency)}`;
  renderText(pdf, totalText, totalsX, yPos, { align: totalsAlign as 'left' | 'right' });
  
  // Payment terms and notes
  yPos += 20;
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  
  if (invoice.paymentTerms) {
    const paymentText = `${labels.paymentTerms}: ${invoice.paymentTerms}`;
    renderText(pdf, paymentText, fromX, yPos, { align: fromAlign as 'left' | 'right' });
    yPos += 10;
  }
  
  if (invoice.notes) {
    const notesLabel = `${labels.notes}:`;
    renderText(pdf, notesLabel, fromX, yPos, { align: fromAlign as 'left' | 'right' });
    yPos += 8;
    
    const notesHeight = renderText(pdf, invoice.notes, fromX, yPos, { 
      align: fromAlign as 'left' | 'right', 
      maxWidth: pageWidth - 40 
    });
    yPos += notesHeight;
  }
  
  // Thank you message
  yPos += 10;
  pdf.setTextColor(102, 102, 102);
  renderText(pdf, labels.thankYou, fromX, yPos, { align: fromAlign as 'left' | 'right' });
  
  // Save the PDF with language code in filename
  const fileName = `invoice-${invoice.invoiceNumber || Date.now()}-${language}.pdf`;
  pdf.save(fileName);
};

export const generateInvoiceSummaryPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  pdf.setFont('helvetica', 'normal');
  
  // Use first invoice's language or default to English
  const language = invoices.length > 0 ? (invoices[0].language || 'en') : 'en';
  const labels = invoices.length > 0 ? getLabels(invoices[0]) : getLabels({ language: 'en' });
  
  // Title
  pdf.setFontSize(20);
  pdf.setTextColor(51, 51, 51);
  renderText(pdf, 'Invoice Summary Report', 20, 30);
  
  // Summary info
  pdf.setFontSize(12);
  pdf.setTextColor(102, 102, 102);
  renderText(pdf, `Generated: ${new Date().toLocaleDateString()}`, 20, 40);
  renderText(pdf, `Total Invoices: ${invoices.length}`, 20, 50);
  
  const totalAmount = invoices.reduce((sum, inv) => sum + (inv.total || 0), 0);
  renderText(pdf, `Total Amount: $${totalAmount.toFixed(2)}`, 20, 60);
  
  // Table
  let yPos = 80;
  pdf.setFillColor(245, 245, 245);
  pdf.rect(20, yPos - 5, pageWidth - 40, 10, 'F');
  
  pdf.setTextColor(51, 51, 51);
  renderText(pdf, 'Invoice #', 25, yPos);
  renderText(pdf, 'Client', 70, yPos);
  renderText(pdf, 'Date', 120, yPos);
  renderText(pdf, 'Amount', pageWidth - 25, yPos, { align: 'right' });
  
  yPos += 15;
  
  invoices.forEach(invoice => {
    if (yPos > 270) {
      pdf.addPage();
      pdf.setFont('helvetica', 'normal');
      yPos = 30;
    }
    
    pdf.setFontSize(10);
    renderText(pdf, invoice.invoiceNumber || '', 25, yPos);
    renderText(pdf, invoice.clientName || '', 70, yPos);
    renderText(pdf, invoice.date ? new Date(invoice.date).toLocaleDateString() : '', 120, yPos);
    renderText(pdf, `$${(invoice.total || 0).toFixed(2)}`, pageWidth - 25, yPos, { align: 'right' });
    
    yPos += 8;
  });
  
  pdf.save(`invoice-summary-${language}.pdf`);
};

export const generateAllInvoicesPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  for (let i = 0; i < invoices.length; i++) {
    if (i > 0) {
      pdf.addPage();
    }
    
    const invoice = invoices[i];
    const language = invoice.language || 'en';
    const labels = getLabels(invoice);
    const currency = invoice.currency || 'USD';
    const pageWidth = pdf.internal.pageSize.getWidth();
    
    pdf.setFont('helvetica', 'normal');
    
    const isRTL = language === 'ar' || language === 'ur';
    const align = isRTL ? 'right' : 'left';
    const x = isRTL ? pageWidth - 20 : 20;
    
    // Header
    pdf.setFontSize(24);
    pdf.setTextColor(51, 51, 51);
    renderText(pdf, labels.invoice, x, 30, { align: align as 'left' | 'right' });
    
    // Invoice number
    pdf.setFontSize(12);
    pdf.setTextColor(102, 102, 102);
    renderText(pdf, `#${invoice.invoiceNumber || ''}`, x, 40, { align: align as 'left' | 'right' });
    
    // Date info
    const dateX = isRTL ? 20 : pageWidth - 20;
    const dateAlign = isRTL ? 'left' : 'right';
    renderText(pdf, `${labels.date}: ${invoice.date || ''}`, dateX, 30, { align: dateAlign as 'left' | 'right' });
    renderText(pdf, `${labels.due}: ${invoice.dueDate || ''}`, dateX, 40, { align: dateAlign as 'left' | 'right' });
    
    // Basic info
    let yPos = 60;
    pdf.setFontSize(12);
    renderText(pdf, `${labels.from}: ${invoice.businessName || ''}`, x, yPos, { align: align as 'left' | 'right' });
    renderText(pdf, `${labels.billTo}: ${invoice.clientName || ''}`, x, yPos + 10, { align: align as 'left' | 'right' });
    
    yPos += 30;
    
    // Items
    renderText(pdf, 'Items:', x, yPos, { align: align as 'left' | 'right' });
    yPos += 10;
    
    (invoice.items || []).forEach(item => {
      pdf.setFontSize(10);
      const itemText = `${item.description} - ${item.quantity} x ${formatCurrency(item.rate, currency)} = ${formatCurrency(item.amount, currency)}`;
      renderText(pdf, itemText, x, yPos, { align: align as 'left' | 'right' });
      yPos += 6;
    });
    
    // Total
    yPos += 10;
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    renderText(pdf, `${labels.total}: ${formatCurrency(invoice.total || 0, currency)}`, x, yPos, { align: align as 'left' | 'right' });
    pdf.setFont('helvetica', 'normal');
  }
  
  pdf.save('all-invoices-multilingual.pdf');
};