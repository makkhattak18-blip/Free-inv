import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { Invoice } from './invoice';

export const generateInvoicePDF = async (invoice: Partial<Invoice>): Promise<void> => {
  try {
    // Create a temporary container for the invoice HTML
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '0';
    container.style.width = '210mm'; // A4 width
    container.style.backgroundColor = 'white';
    container.style.padding = '20mm';
    container.style.fontFamily = 'Arial, sans-serif';
    container.style.fontSize = '12px';
    container.style.lineHeight = '1.4';
    container.style.boxSizing = 'border-box';
    
    // Get the invoice template element from the DOM
    const invoicePreview = document.querySelector('[data-invoice-preview]') as HTMLElement;
    
    if (invoicePreview) {
      // Clone the existing preview
      container.innerHTML = invoicePreview.innerHTML;
    } else {
      // Fallback: create invoice HTML manually
      container.innerHTML = createInvoiceHTML(invoice);
    }
    
    // Add to DOM temporarily
    document.body.appendChild(container);
    
    // Wait for images to load
    const images = container.querySelectorAll('img');
    await Promise.all(Array.from(images).map(img => {
      if (img.complete) return Promise.resolve();
      return new Promise(resolve => {
        img.onload = resolve;
        img.onerror = resolve;
      });
    }));
    
    // Convert to canvas with high quality
    const canvas = await html2canvas(container, {
      scale: 2, // Higher resolution
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      width: container.offsetWidth,
      height: container.offsetHeight,
      scrollX: 0,
      scrollY: 0,
      windowWidth: container.offsetWidth,
      windowHeight: container.offsetHeight
    });
    
    // Remove temporary container
    document.body.removeChild(container);
    
    // Create PDF with exact dimensions
    const imgData = canvas.toDataURL('image/png');
    const imgWidth = 210; // A4 width in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const pageHeight = 297; // A4 height in mm
    
    // Create PDF with calculated height
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    // If content fits on one page, just add it
    if (imgHeight <= pageHeight) {
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
    } else {
      // Content spans multiple pages
      let remainingHeight = imgHeight;
      let position = 0;
      let pageNumber = 0;
      
      while (remainingHeight > 0) {
        if (pageNumber > 0) {
          pdf.addPage();
        }
        
        const currentPageHeight = Math.min(remainingHeight, pageHeight);
        
        // Create a cropped version of the image for this page
        const cropCanvas = document.createElement('canvas');
        const cropCtx = cropCanvas.getContext('2d');
        
        cropCanvas.width = canvas.width;
        cropCanvas.height = (currentPageHeight / imgHeight) * canvas.height;
        
        if (cropCtx) {
          cropCtx.drawImage(
            canvas,
            0, (position / imgHeight) * canvas.height, // source x, y
            canvas.width, cropCanvas.height, // source width, height
            0, 0, // destination x, y
            canvas.width, cropCanvas.height // destination width, height
          );
          
          const croppedImgData = cropCanvas.toDataURL('image/png');
          pdf.addImage(croppedImgData, 'PNG', 0, 0, imgWidth, currentPageHeight);
        }
        
        remainingHeight -= currentPageHeight;
        position += currentPageHeight;
        pageNumber++;
      }
    }
    
    // Save the PDF
    const fileName = `invoice-${invoice.invoiceNumber || Date.now()}.pdf`;
    pdf.save(fileName);
    
  } catch (error) {
    console.error('PDF generation error:', error);
    // Fallback to simple text PDF
    await generateFallbackPDF(invoice);
  }
};

const createInvoiceHTML = (invoice: Partial<Invoice>): string => {
  const language = invoice.language || 'en';
  const isRTL = language === 'ar' || language === 'ur';
  
  return `
    <div style="direction: ${isRTL ? 'rtl' : 'ltr'}; text-align: ${isRTL ? 'right' : 'left'}; min-height: auto;">
      ${invoice.businessLogo ? `
        <div style="text-align: center; margin-bottom: 20px;">
          <img src="${invoice.businessLogo}" style="max-width: 200px; max-height: 100px;" />
        </div>
      ` : ''}
      
      <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
        <div>
          <h1 style="font-size: 28px; margin: 0; color: #333;">${invoice.customLabels?.invoice || 'Invoice'}</h1>
          <p style="margin: 5px 0; color: #666;">#${invoice.invoiceNumber || ''}</p>
        </div>
        <div style="text-align: right;">
          <p style="margin: 5px 0;"><strong>${invoice.customLabels?.date || 'Date'}:</strong> ${invoice.date || ''}</p>
          <p style="margin: 5px 0;"><strong>${invoice.customLabels?.due || 'Due Date'}:</strong> ${invoice.dueDate || ''}</p>
        </div>
      </div>
      
      <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
        <div style="width: 45%;">
          <h3 style="margin: 0 0 10px 0; color: #333;">${invoice.customLabels?.from || 'From'}</h3>
          <p style="margin: 2px 0; font-weight: bold;">${invoice.businessName || ''}</p>
          <p style="margin: 2px 0; white-space: pre-line;">${invoice.businessAddress || ''}</p>
          <p style="margin: 2px 0;">${invoice.businessEmail || ''}</p>
          <p style="margin: 2px 0;">${invoice.businessPhone || ''}</p>
        </div>
        <div style="width: 45%; text-align: ${isRTL ? 'left' : 'right'};">
          <h3 style="margin: 0 0 10px 0; color: #333;">${invoice.customLabels?.billTo || 'Bill To'}</h3>
          <p style="margin: 2px 0; font-weight: bold;">${invoice.clientName || ''}</p>
          <p style="margin: 2px 0; white-space: pre-line;">${invoice.clientAddress || ''}</p>
          <p style="margin: 2px 0;">${invoice.clientEmail || ''}</p>
        </div>
      </div>
      
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
        <thead>
          <tr style="background-color: #f5f5f5;">
            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">${invoice.customLabels?.description || 'Description'}</th>
            <th style="padding: 12px; border: 1px solid #ddd; text-align: center;">${invoice.customLabels?.quantity || 'Qty'}</th>
            <th style="padding: 12px; border: 1px solid #ddd; text-align: right;">${invoice.customLabels?.rate || 'Rate'}</th>
            <th style="padding: 12px; border: 1px solid #ddd; text-align: right;">${invoice.customLabels?.amount || 'Amount'}</th>
          </tr>
        </thead>
        <tbody>
          ${(invoice.items || []).map(item => `
            <tr>
              <td style="padding: 12px; border: 1px solid #ddd;">
                ${item.description}
                ${item.image ? `<br><img src="${item.image}" style="max-width: 50px; max-height: 50px; margin-top: 5px;" />` : ''}
              </td>
              <td style="padding: 12px; border: 1px solid #ddd; text-align: center;">${item.quantity}</td>
              <td style="padding: 12px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.rate, invoice.currency || 'USD')}</td>
              <td style="padding: 12px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.amount, invoice.currency || 'USD')}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <div style="text-align: right; margin-bottom: 20px;">
        <p style="margin: 5px 0;"><strong>${invoice.customLabels?.subtotal || 'Subtotal'}:</strong> ${formatCurrency(invoice.subtotal || 0, invoice.currency || 'USD')}</p>
        ${(invoice.taxRate || 0) > 0 ? `
          <p style="margin: 5px 0;"><strong>${invoice.customLabels?.tax || 'Tax'} (${invoice.taxRate}%):</strong> ${formatCurrency(invoice.taxAmount || 0, invoice.currency || 'USD')}</p>
        ` : ''}
        <p style="margin: 5px 0; font-size: 18px; font-weight: bold; color: #333;">
          <strong>${invoice.customLabels?.total || 'Total'}:</strong> ${formatCurrency(invoice.total || 0, invoice.currency || 'USD')}
        </p>
      </div>
      
      ${invoice.paymentTerms ? `
        <div style="margin-bottom: 15px;">
          <h4 style="margin: 0 0 5px 0; color: #333;">${invoice.customLabels?.paymentTerms || 'Payment Terms'}</h4>
          <p style="margin: 0;">${invoice.paymentTerms}</p>
        </div>
      ` : ''}
      
      ${invoice.notes ? `
        <div style="margin-bottom: 15px;">
          <h4 style="margin: 0 0 5px 0; color: #333;">${invoice.customLabels?.notes || 'Notes'}</h4>
          <p style="margin: 0; white-space: pre-line;">${invoice.notes}</p>
        </div>
      ` : ''}
      
      <div style="text-align: center; margin-top: 30px; color: #666;">
        <p>${invoice.customLabels?.thankYou || 'Thank you for your business!'}</p>
      </div>
    </div>
  `;
};

const formatCurrency = (amount: number, currency: string): string => {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
  } catch {
    return `${currency} ${amount.toFixed(2)}`;
  }
};

const generateFallbackPDF = async (invoice: Partial<Invoice>): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  pdf.setFont('helvetica', 'normal');
  
  // Simple fallback PDF
  pdf.setFontSize(20);
  pdf.text('Invoice', 20, 30);
  
  pdf.setFontSize(12);
  pdf.text(`#${invoice.invoiceNumber || ''}`, 20, 40);
  pdf.text(`Date: ${invoice.date || ''}`, 20, 50);
  pdf.text(`Client: ${invoice.clientName || ''}`, 20, 60);
  pdf.text(`Total: ${formatCurrency(invoice.total || 0, invoice.currency || 'USD')}`, 20, 70);
  
  const fileName = `invoice-${invoice.invoiceNumber || Date.now()}-fallback.pdf`;
  pdf.save(fileName);
};

export const generateInvoiceSummaryPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  pdf.setFont('helvetica', 'normal');
  
  pdf.setFontSize(20);
  pdf.text('Invoice Summary Report', 20, 30);
  
  pdf.setFontSize(12);
  pdf.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 45);
  pdf.text(`Total Invoices: ${invoices.length}`, 20, 55);
  
  const totalAmount = invoices.reduce((sum, inv) => sum + (inv.total || 0), 0);
  pdf.text(`Total Amount: $${totalAmount.toFixed(2)}`, 20, 65);
  
  pdf.save('invoice-summary.pdf');
};

export const generateAllInvoicesPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  for (let i = 0; i < invoices.length; i++) {
    if (i > 0) pdf.addPage();
    
    const invoice = invoices[i];
    pdf.setFont('helvetica', 'normal');
    
    pdf.setFontSize(20);
    pdf.text('Invoice', 20, 30);
    
    pdf.setFontSize(12);
    pdf.text(`#${invoice.invoiceNumber || ''}`, 20, 45);
    pdf.text(`Client: ${invoice.clientName || ''}`, 20, 55);
    pdf.text(`Total: ${formatCurrency(invoice.total || 0, invoice.currency || 'USD')}`, 20, 65);
  }
  
  pdf.save('all-invoices.pdf');
};