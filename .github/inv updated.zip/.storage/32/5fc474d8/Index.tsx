import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Download, 
  Clock, 
  Shield, 
  Smartphone, 
  Zap,
  CheckCircle,
  Star,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24">
        <div className="text-center max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">
            ✨ Professional Invoice Generator
          </Badge>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Create Professional 
            <span className="text-blue-600 block">Invoices in Minutes</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            Generate, customize, and send professional invoices instantly. 
            No signup required. Perfect for freelancers, small businesses, and contractors.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Link to="/create">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Create Invoice Now</span>
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            
            <Link to="/dashboard">
              <Button variant="outline" size="lg" className="px-8 py-6 text-lg font-semibold rounded-xl border-2 hover:bg-gray-50 transition-all duration-200">
                View Sample Invoice
              </Button>
            </Link>
          </div>
          
          <div className="flex justify-center items-center space-x-8 text-sm text-gray-500">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>No Registration</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Instant PDF Download</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>100% Free</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Everything You Need for Professional Invoicing
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our invoice creator includes all the features you need to get paid faster
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="p-6 hover:shadow-lg transition-shadow duration-200 border-0 shadow-md">
            <CardContent className="p-0">
              <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Lightning Fast</h3>
              <p className="text-gray-600">Create professional invoices in under 2 minutes. No complex setup or learning curve.</p>
            </CardContent>
          </Card>
          
          <Card className="p-6 hover:shadow-lg transition-shadow duration-200 border-0 shadow-md">
            <CardContent className="p-0">
              <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Download className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Instant PDF Export</h3>
              <p className="text-gray-600">Download your invoices as professional PDF files ready to send to clients.</p>
            </CardContent>
          </Card>
          
          <Card className="p-6 hover:shadow-lg transition-shadow duration-200 border-0 shadow-md">
            <CardContent className="p-0">
              <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Smartphone className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Mobile Friendly</h3>
              <p className="text-gray-600">Create and manage invoices on any device. Fully responsive design.</p>
            </CardContent>
          </Card>
          
          <Card className="p-6 hover:shadow-lg transition-shadow duration-200 border-0 shadow-md">
            <CardContent className="p-0">
              <div className="bg-orange-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Save Time</h3>
              <p className="text-gray-600">Store your business details and client information for faster invoice creation.</p>
            </CardContent>
          </Card>
          
          <Card className="p-6 hover:shadow-lg transition-shadow duration-200 border-0 shadow-md">
            <CardContent className="p-0">
              <div className="bg-red-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Secure & Private</h3>
              <p className="text-gray-600">Your data stays in your browser. We don't store any personal information.</p>
            </CardContent>
          </Card>
          
          <Card className="p-6 hover:shadow-lg transition-shadow duration-200 border-0 shadow-md">
            <CardContent className="p-0">
              <div className="bg-indigo-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Star className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Professional Templates</h3>
              <p className="text-gray-600">Clean, professional invoice templates that make your business look credible.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Create Your First Invoice?</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Join thousands of professionals who trust InvoicePro for their billing needs
          </p>
          
          <Link to="/create">
            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200">
              Start Creating Invoices - It's Free!
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-600">
          <p>&copy; 2024 InvoicePro. Built with ❤️ for professionals worldwide.</p>
        </div>
      </footer>
    </div>
  );
}